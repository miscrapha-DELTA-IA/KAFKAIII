import unittest
import math, random
import experiment_v1_9g as g
import experiment_v1_9e as old

class TestModelAndEvaluation(unittest.TestCase):
    def test_posterior_normalization(self):
        for m in (g.H20,g.MIX):
            self.assertAlmostEqual(sum(m.w0),1.,places=8)
            for sign in (True,False):
                self.assertAlmostEqual(sum(m.update(m.w0,sign)),1.,places=8)
                self.assertAlmostEqual(sum(m.predict(m.update(m.w0,sign))),1.,places=8)
    def test_signal_direction(self):
        self.assertGreater(g.H20.probability(g.H20.update(g.H20.w0,True)),g.H20.probability(g.H20.w0))
        self.assertLess(g.H20.probability(g.H20.update(g.H20.w0,False)),g.H20.probability(g.H20.w0))
    def test_transition_formula(self):
        m=g.H20
        w=m.update(m.w0,True)
        p=m.probability(w)
        self.assertAlmostEqual(m.probability(m.predict(w)),p*.8+(1-p)*.2,places=8)
    def test_bellman_horizon_one(self):
        for m in (g.H20,g.MIX):
            self.assertAlmostEqual(m.value(1,m.w0,2),min(m.instant(m.w0,e) for e in old.GRID))
    def test_data_timestamp_matters(self):
        m=g.H20
        old_evidence=m.forward(4,{0:True})
        fresh_evidence=m.forward(4,{3:True})
        self.assertGreater(m.probability(fresh_evidence),m.probability(old_evidence))
    def test_midpoint_acquisition(self):
        self.assertGreater(old.q_of(.5,.02,.82),old.q_of(1,.02,.82))
    def test_no_budget(self):
        for policy in ('markov_dp_h20','markov_model_average_dp','kafka_temporal_guard','dynamic_worst_model'):
            b=g.MIX.w0 if policy!='markov_dp_h20' else g.H20.w0
            self.assertIn(g.select_new(policy,1,0,b,(0.,1.)),(0.,1.))
    def test_no_true_theta_argument(self):
        # Only allowed inputs to a policy: t, budget, belief and legal set.
        self.assertEqual(g.select_new('kafka_temporal_guard',0,2,g.MIX.w0,tuple(old.GRID)),
                         g.select_new('kafka_temporal_guard',0,2,g.MIX.w0,tuple(old.GRID)))
    def test_common_exogenous(self):
        e=g.FAMILIES[-1]
        theta,u=g.generate(e,0,random.Random(8))
        theta2,u2=g.generate(e,0,random.Random(8))
        self.assertEqual((theta,u),(theta2,u2))
    def test_budget_all_families(self):
        for env in g.FAMILIES:
            theta,u=g.generate(env,0,random.Random(123))
            for policy in g.POLICIES:
                v,actions=g.simulate(env,policy,theta,u)
                self.assertEqual(len(actions),g.H)
                self.assertLessEqual(v['probes'],2)
                self.assertAlmostEqual(v['total'],v['biological']+v['acquisition']+v['review']+v['congestion'],places=9)
    def test_nonnegative_loss(self):
        env=g.FAMILIES[0]
        theta,u=g.generate(env,0,random.Random(456))
        for p in g.POLICIES:
            v,_=g.simulate(env,p,theta,u)
            self.assertGreaterEqual(v['total'],0)
    def test_equal_information_model(self):
        # Each dynamic policy filters only received source-timestamped events.
        events={0:True,2:False}
        self.assertEqual(g.MIX.forward(4,events),g.MIX.forward(4,dict(events)))

if __name__=='__main__':unittest.main(verbosity=2)
