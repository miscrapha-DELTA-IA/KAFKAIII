---
title: "KAFKA III — Auditoria de desenvolvimento v1.9G e contrato de segurança v1.9H"
subtitle: "Resultados de falsificação, limites da superioridade e plano de redesenho"
author: "Relatório técnico interno — autoria científica a definir"
date: "12 de novembro de 2026"
lang: pt-BR
geometry: margin=2.0cm
fontsize: 10pt
mainfont: DejaVu Sans
---

> **CLASSIFICAÇÃO:** experimentação inteiramente sintética, exploratória, executada e examinada internamente. Não é ensaio clínico, pré-registro público, prova de efeito causal, protocolo regulatório ou validação independente. 

## Síntese executiva

Foram simuladas **22 famílias × 8 políticas × 800 trajetórias = 140.800 trajetórias**, cada uma com seis decisões sintéticas; 19 testes unitários novos foram executados (12 da v1.9G e 7 do filtro v1.9H). O experimento manteve os cenários originais adversariais da v1.9E e adicionou quatro famílias Markov predefinidas. Todos os resultados — inclusive os negativos — estão nos CSVs. A regra candidata `kafka_temporal_guard` **não atingiu superioridade global** e não superou o melhor comparador em nenhuma das 22 famílias por média amostral.

No cenário `benefit_to_harm`, a regra KAFKA obteve perda média **0.3393** versus **0.3545** para o planejador de mistura dinâmica. A diferença favorável foi **0.0151**, IC Monte Carlo Bonferroni 154 contrastes **[0.0010; 0.0292]**. Esse resultado positivo é estritamente local ao cenário e não repara os resultados negativos de outras famílias.

### Descoberta central

O mecanismo de exigir consenso entre modelos antes de confiar em exposição extrema teve custo elevado em vários cenários. Uma melhor arquitetura KAFKA não deve converter automaticamente discordância posterior em sondagem ou suspensão, nem substituir planejamento dinâmico por veto heurístico; precisa incorporar uma **restrição verificável de deterioração frente à referência**, otimizar o valor da informação dentro das ações protegidas e estimar o efeito causal da exibição com desenho identificável.

## 1. Contrato experimental da v1.9G

- **Observação:** sinal binário de um gerador abstrato; seu mecanismo não equivale a ensaio clínico randomizado. A probabilidade de receber sinal `q(e)=0,02 + 4(0,82−0,02)e(1−e)` é positiva mesmo em exposição 0 ou 1, impossibilitando interpretar esse canal como uma comparação causal identificada por dois braços nesses extremos.
- **Estados:** efeito latente sintético −0,1, 0 ou +0,1; o estado verdadeiro é visível só ao avaliador. As quatro famílias adicionais incluem hazard de alternância 0,08, 0,20, 0,40 e mudança 0,05 para 0,45.
- **Ações e custos:** mesma grade, orçamento máximo de duas ações intermediárias, contingência no conflito de permissões, custo de aquisição, congestionamento proxy e revisão. As ações possíveis são as mesmas para as oito políticas; o gate extra é escolhido **apenas** pelo candidato KAFKA.
- **História:** coorte da observação preservada quando o sinal chega tarde; filtros dinâmicos são reconstruídos com timestamps, mas os planejadores antecipam observação em t+1. O planejador de mistura não é solução de POMDP robusto minimax.
- **Estatística:** contrastes pareados por uniformes exógenos compartilhados; intervalos MC normais descritivos, com uma correção Bonferroni para 154 contrastes (22 famílias × 7 comparadores). Nem essa correção nem a data do protocolo criam avaliação cega.

### Comparadores

- `nominal_static_dp`: Bellman exato dentro do modelo de efeito estático e acurácia 0,85.
- `static_accuracy_mix_dp`: Bellman exato dentro da mistura estática de acurácia 0,55/0,85.
- `markov_dp_h20`: Bellman de um modelo de alternância de sinal com hazard 0,20 e acurácia 0,85.
- `markov_model_average_dp`: Bellman da mistura de hazard (0/0,20/0,40) e acurácia (0,55/0,85).
- `dynamic_worst_model`: minimax imediato entre filtros ponderados; não é minimax POMDP multietapas.
- `kafka_gate_e`: regra histórica KAFKA simplificada da v1.9E.
- `safe_static_proxy_e`: exposição conservadora proxy, NÃO o safe policy learning da v1.8A.

## 2. Resultados completos, 22 famílias

Menor perda é melhor. Escala sintética acumulada, sem calibração clínica.

| Família | KAFKA temporal | Bayes nominal | Bayes Markov 0,20 | Bayes mistura Markov |
|:---|---:|---:|---:|---:|
| `nominal_static` | 0.1627 | 0.1318 | 0.1654 | 0.1480 |
| `always_benefit` | 0.2013 | 0.1497 | 0.1871 | 0.2108 |
| `always_harm` | 0.1313 | 0.1311 | 0.1524 | 0.0913 |
| `null_effect` | 0.0017 | 0.0014 | 0.0017 | 0.0014 |
| `harm_to_benefit` | 0.3972 | 0.3384 | 0.2187 | 0.3378 |
| `benefit_to_harm` | 0.3393 | 0.3311 | 0.2295 | 0.3545 |
| `reversao_dupla` | 0.2952 | 0.2745 | 0.3326 | 0.2598 |
| `dois_estratos` | 0.1690 | 0.1376 | 0.1746 | 0.1532 |
| `inverted_signal` | 0.3936 | 0.4206 | 0.3989 | 0.3966 |
| `weak_signal` | 0.2750 | 0.2710 | 0.2766 | 0.2654 |
| `prior_shift` | 0.1876 | 0.1508 | 0.1823 | 0.2010 |
| `censura_MNAR` | 0.1595 | 0.1371 | 0.1564 | 0.1519 |
| `delayed_outcomes` | 0.1921 | 0.1921 | 0.1993 | 0.1897 |
| `weak_positivity` | 0.2462 | 0.2429 | 0.2476 | 0.2425 |
| `congestao_proxy` | 0.2370 | 0.2242 | 0.2487 | 0.2073 |
| `conflito_governanca` | 0.2621 | 0.2340 | 0.2355 | 0.2368 |
| `grid_only_gap` | 0.1667 | 0.1665 | 0.1670 | 0.1648 |
| `drift_acuracia` | 0.1407 | 0.1113 | 0.2271 | 0.1244 |
| `markov_switch_08` | 0.2177 | 0.2063 | 0.2011 | 0.2000 |
| `markov_switch_20` | 0.2648 | 0.2518 | 0.2387 | 0.2444 |
| `markov_switch_40` | 0.2966 | 0.2997 | 0.2938 | 0.2922 |
| `Markov_hazard_shift` | 0.2697 | 0.2500 | 0.2477 | 0.2527 |

Os nomes completos e sem abreviações de todas as famílias estão nos arquivos CSV de resultados.


### Confronto com cada comparador

| Comparador | Famílias em que KAFKA tem menor média (de 22) | Bonferroni 154: favorecem KAFKA | Bonferroni 154: favorecem comparador |
|:---|---:|---:|---:|
| `kafka_gate_e` | 9 | 5 | 7 |
| `nominal_static_dp` | 2 | 1 | 12 |
| `static_accuracy_mix_dp` | 1 | 0 | 13 |
| `markov_dp_h20` | 11 | 3 | 5 |
| `markov_model_average_dp` | 4 | 1 | 10 |
| `dynamic_worst_model` | 14 | 8 | 6 |
| `safe_static_proxy_e` | 14 | 9 | 6 |

Os 154 contrastes completos, sem descartar falhas, estão em `paired_v1_9g.csv`. Os limites Bonferroni são para incerteza **de Monte Carlo sob este simulador**, não intervalos causais nem cobertura robusta a seleção de métodos/cenários. A escolha do melhor comparador após observar resultados deve ser entendida somente como diagnóstico.

![Contrastes pareados: diferença de perda Bayes mistura − KAFKA temporal, com IC Monte Carlo Bonferroni 154.](figure_bayes_mix_vs_kafka.png){ width=88% }

## 3. Por que a superioridade ampla continua bloqueada

1. **Ótimo nominal:** no modelo correto, com as mesmas informações, custos e direitos, a política Bayes ótima minimiza perda esperada. Uma regra distinta não pode ter desempenho esperado melhor sob exatamente esse modelo e a mesma função objetivo.
2. **Custo da prudência:** forçar exposição 0,5 sob discordância reduz exposição extrema, mas gasta orçamento e pode aumentar o arrependimento no benefício persistente.
3. **Efeito de informação:** ações mudam a observabilidade; suspensão por evidência insuficiente pode agravar a própria insuficiência de evidência.
4. **Inversão de sinal:** sem âncora independente, inverter o canal pode tornar o efeito e a evidência observada indistinguíveis. “Mais confiança” não corrige rótulos invertidos.
5. **Comparação incompleta:** nem a v1.9E nem a v1.9G implementaram uma revisão clínica, um estimando causal de exibição observado ou o seguro `safe policy learning` histórico exato no mesmo ambiente.
6. **Sem autonomia para autorização clínica:** assinatura, direitos de exposição e custos humanos devem ser definidos exogenamente por governança humana.

## 4. Novo núcleo matemático recomendado para v1.9H

O núcleo não deve tentar reinventar `safe policy learning`. Ele pode usá-lo como **camada verificável e comum** de proteção, depois otimizar planejamento dinâmico auditável dentro do espaço admissível.

Se `Δ_t = E[Y_t(1)−Y_t(0)]` é o efeito causal *futuro* da exibição para uma população elegível e a perda é `loss(e,Δ)=(1−e)max(Δ,0)+e max(−Δ,0)`, então, sem interferência e para o mesmo efeito fixo dentro do período:

$$\ell(e,\Delta)-\ell(e_0,\Delta)=(e_0-e)\Delta.$$

Para um conjunto **legítimo e prospectivo** `Θ_t=[L_t,U_t]` e tolerância externa `η_t≥0`, definimos ações seguras:

$$\mathcal E_t^{\rm safe}=\left\{e\in\mathcal E_t: \max_{\delta\in[L_t,U_t]}(e_{0,t}-e)\delta\leq\eta_t\right\}.$$

Se, em todos os períodos, o efeito futuro verdadeiro realmente pertence a `Θ_t`, cada decisão é escolhida nesse conjunto e os custos extraordinários foram controlados separadamente, o excesso de **perda esperada** sobre a referência é limitado por `Ση_t`. A prova é somar as desigualdades anteriores. Quando o limite futuro não é válido, a garantia desaparece; quando há interferência, os estimandos precisam ser definidos para regimes hospitalares. A proposição é elementar e **não reivindicada como inédita**.

O arquivo `safety_contract_v1_9h.py` contém um filtro de ações e um verificador apenas para o avaliador, com 7 testes. O filtro falha explicitamente (`None`) quando o conjunto seguro é vazio, em vez de forçar ação regular. **Esse arquivo não foi usado para reotimizar os resultados da v1.9G.**

## 5. Próximo experimento realmente discriminante

### Fase A — identificação causal (pré-condição)

- Definir população elegível antes da decisão, `Z` exibição de recomendação, `T` tratamento, `D` decisão, `Y` desfecho verdadeiro, `C_obs` registro. Estimando primário: intenção de tratar da **exibição** `Δ_Z,t`, sem confundi-lo com efeito biológico do tratamento ou efeito de implantar o sistema.
- Substituir o sinal abstrato da v1.9G por alocação randomizada com propensão registrada em dois braços quando eticamente permitida, atraso de desfecho e censura com hipótese identificável/sensibilidade. A ausência de contraste entre braços implica estado de **não identificação**, não atualização artificial.
- Calibrar custo de alerta, dano por supressão, sobrecarga e autonomia com especialistas e avaliação ética, em vez de escolher pesos para ganhar simulações.

### Fase B — arquitetura competitiva KAFKA III

- Motor de inferência causal: estimador com propensity logging, pré-especificação de intervalos sob observabilidade adequada, correção/limites para não observação e relógio de coorte.
- Motor de planejamento: POMDP Bayes com mudança temporal, incerteza sobre transição e observação, aquisição e atraso; mesmo otimizador de referência para todos os métodos.
- Camada de autoridade: limite externo de deterioração em relação ao cuidado de referência, validade temporal da evidência, contingência fora da decisão regular, auditoria de todas as decisões, com autorização exógena.
- Separar política operacional de estado administrativo: a revisão não cria novas observações nem identifica causalidade; não tratar o gate de reentrada autoimposto como veto legal aos concorrentes.

### Fase C — validação e critérios de avanço

- Registrar publicamente estimando, permissões idênticas, perdas, margens, cenários e critérios de vitória *antes* de entregar dados/sementes finais a avaliador cego.
- Incluir baselines de mesma classe: safe policy learning equivalente à v1.8A no ambiente causal, Bayes corretamente especificado, Bayes com incerteza paramétrica e robust POMDP/minimax multietapas real; manter sempre ligado/desligado e sentinela.
- **Critério de vitória:** diferença positiva de perda (comparador − KAFKA) em família relevante previamente definida, com correção de múltiplos testes; nenhuma violação do limite de segurança acordado em famílias falsificadoras; resultados independentes e reproduzíveis.
- Se o ganho não superar alternativas de mesma classe, não alegar superioridade: publicar os resultados de limite/decisão e negativos.

## 6. Integridade e reprodutibilidade

- Documento de protocolo preservado com SHA-256: `e77677c4a1b33c3f5049eddbb0ad49c0a56d30cae2389dac867477a89d56f5d2`. Isso fornece trilha interna, **não** pré-registro independente.

- 12 testes de motor/filtro v1.9G aprovados; 7 testes adicionais de segurança v1.9H aprovados. Código v1.9E de origem incluso para reconstrução.
- Conjuntos `metrics_v1_9g.csv` (22×8), `paired_v1_9g.csv` (22×7), `audit_paths_v1_9g.csv` (cinco episódios por família e política, com estados `theta_evaluator_only`), `execution_manifest.json`, `run_v1_9g.log` e logs de teste estão no pacote.
- Execução: `python test_v1_9g.py`; `python test_safety_contract_v1_9h.py`; `python experiment_v1_9g.py`. A simulação original v1.9E permanece arquivada e não foi modificada.

## 7. Antecedentes que limitam reivindicações de novidade

- Joshi, Zhang & Bareinboim (2024), *Towards Safe Policy Learning under Partial Identifiability: A Causal Approach*, AAAI. https://ojs.aaai.org/index.php/AAAI/article/view/29198
- Ben-Michael, Greiner, Imai & Jiang (2025), *Safe Policy Learning through Extrapolation*, JASA. https://imai.fas.harvard.edu/research/files/safe.pdf
- Galesloot et al. (2025), *Robust Finite-Memory Policy Gradients for Hidden-Model POMDPs*, IJCAI. https://ijcai.org/proceedings/2025/947
- Galesloot et al. (2026), *Pessimistic Iterative Planning with RNNs for Robust POMDPs*, ECAI. https://journals.sagepub.com/doi/10.3233/FAIA251391
- Li & Xiang (2025/2026), *Distributionally Robust Partially Observable Markov Decision Process with Distance-Based Ambiguity Sets*, IISE Transactions. https://doi.org/10.1080/24725854.2025.2505980

## Parecer final

**NÃO HÁ SUPERIORIDADE GERAL DEMONSTRADA.** A v1.9G aumenta o rigor ao acrescentar planejadores com mudança temporal e publicar falhas, mas mostra que o gate de consenso é excessivamente conservador. O progresso substantivo é a direção v1.9H: alinhar identificação causal, segurança condicional verificável e POMDP forte, sem manipular funções de perda ou excluir ambientes desfavoráveis. Os resultados da v1.9G devem figurar como suplemento negativo de desenvolvimento, não ser adicionados ao preprint como confirmação de eficácia.
