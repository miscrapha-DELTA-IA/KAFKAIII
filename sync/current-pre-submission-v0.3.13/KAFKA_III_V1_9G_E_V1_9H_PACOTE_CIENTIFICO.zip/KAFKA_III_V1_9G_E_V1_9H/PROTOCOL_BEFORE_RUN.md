# KAFKA III v1.9G — Protocolo interno de desenvolvimento (pré-execução)
Data: 2026-11-12. Status: **exploratório**, desenhado e executado pelo mesmo pesquisador; sem pré-registro público, sem avaliação cega, sem validação clínica.

## Hipótese e identificação
Testar se um controlador temporal robusto que usa a mesma informação e o mesmo conjunto externo de ações e custos pode reduzir perda de decisão de uma regra KAFKA anterior e de uma política Bayes estática **sob mudanças de efeito**, reconhecendo que não pode dominar o Bayes ótimo no modelo estático nominal. Comparar explicitamente com filtros e planejadores dinâmicos fortes; superioridade incremental sobre eles não é pressuposta. Perdas são sintéticas, não unidades clínicas.

## Desenho fixado
Horizonte 6, efeito ±0.10 ou zero, e∈{0,.25,.5,.75,1}, orçamento ≤2 exposições intermediárias, aquisição q(e)=.02+4*(.82-.02)*e*(1-e), custo aquisição .001 por sinal potencial, revisão .02 por conflito, congestão apenas proxy, permissões, contingência e limites idênticos para todas as políticas. N=800 episódios/ família como em v1.9E, número de famílias=22: as 18 famílias originais e Markov (.08,.20,.40) e mudanças de hazard (.05→.45). As políticas não recebem θ verdadeiro, acurácia real, timing real de reversão nem variáveis de avaliador. Uniformes exógenos compartilhados em cada episódio e semente disjunta por família `20261112+1319*i`. Atribuição do estado latente Markov independente da escolha de exposição.

## Métodos
- `kafka_gate_e`: regra KAFKA v1.9E original (comparador histórico, não arquitetura integral)
- `nominal_static_dp`: programação dinâmica exata do modelo estático nominal (.85), conforme v1.9E
- `static_accuracy_mix_dp`: Bayes exato do modelo estático com mistura de acurácias (.55,.85), conforme v1.9E
- `markov_dp_h20`: programação dinâmica exata do modelo Markov (.20,.85) em regime de sinais com entrega t+1; com atraso adicional o modelo é mal especificado
- `markov_model_average_dp`: programação dinâmica Bayes exata para mistura fixa de hazards (0,.2,.4) e precisão (.55,.85), com crenças conjuntas estado×modelo (aproximação de arredondamento numérico). Entrega t+1 presumida no planejador; retrodatar sinais no filtro quando o gerador efetivamente atrasa
- `kafka_temporal_guard`: mesma crença e valor de informação da mistura Markov, mas exige consenso de probabilidade (mínimo >.70 ou máximo <.30 nos modelos com peso posterior >=.04) para adotar decisão de autoridade extrema; caso contrário favorece ação de exposição .5 se orçamento permitir, ou ação terminal minimax de perda imediata por modelo quando esgotado. Esse gate é autoimposto e **não restringe direitos dos comparadores**.
- `dynamic_worst_model`: usa a mesma crença da mistura, escolhe ação minimizando pior perda esperada de um período entre modelos com peso >=.04; sem planejamento de informação: comparador de estresse, não robust POMDP multietapas ótimo.
- `safe_static_proxy_e`: exposição conservadora proxy v1.9E; NÃO equivalência ao safe-policy histórico v1.8A.

## Métrica e critério
Perda total acumulada no simulador. Principal: média das diferenças pareadas (`comparator - kafka_temporal_guard`) em cada família, com IC MC marginal de 95%; secundário: IC normal conservador Bonferroni sobre **22 famílias × 7 comparadores =154** contrastes (descritivo; não pré-registro externo), comparação direta com o melhor baseline por família; falso afastamento de benefício e falsa exposição a dano usando θ **apenas no avaliador**; fração de períodos sem informação. Reportar TODAS as famílias, sem seleção. Não reivindicar performance clínica, significância causal, ou garantia minmax robusta. Testar invariantes de orçamento, geração da evidência, admissibilidade, zero acesso à verdade e filtros. Os resultados poderão servir para selecionar nova hipótese, mas qualquer seleção invalida confirmação neste mesmo gerador.

## Gate
Não avançar como artigo de superioridade se falhar contra `markov_model_average_dp` e `markov_dp_h20`, ou se vantagem só existir por restrição/baseline inadequado. Se políticas empatarem, registrar. Novo protocolo externo, custos legitimados e avaliação cega continuam necessários.
