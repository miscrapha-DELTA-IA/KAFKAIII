import unittest,itertools,random
from safety_contract_v1_9h import *
class TestSafeFrontier(unittest.TestCase):
    def test_exact_identity(self):
        for e,e0,d in itertools.product([0,.05,.25,.5,.75,.95,1],[0,.5,.95,1],[-.3,-.1,0,.1,.3]):
            self.assertAlmostEqual(loss(e,d)-loss(e0,d),(e0-e)*d,places=12)
    def test_v18a_safety_grid(self):
        A=(0,.05,.25,.50,.75,.95)
        self.assertEqual(safe_actions(A,.95,-.25,.05,.005),(.95,))
        self.assertEqual(safe_actions(A,.95,-.25,.05,.02),(.75,.95))
        self.assertEqual(guard_bayes_action({e:max(loss(e,-.25),loss(e,.05)) for e in A},.95,-.25,.05,.05),.05)
    def test_symmetric_hedging(self):
        self.assertEqual(safe_actions((0,.25,.5,.75,1),.5,-.1,.1,.02),(.5,))
    def test_empty_does_not_force(self):
        self.assertIsNone(guard_bayes_action({0:0.,1:0.},.5,-.1,.1,.01))
    def test_path_certificate(self):
        rng=random.Random(1)
        s=[]
        for i in range(500):
            L,U=(-.05,.15) if i%2 else (-.20,.10)
            e0=.95; eta=.02
            allowed=safe_actions((0,.05,.25,.5,.75,.95),e0,L,U,eta)
            e=rng.choice(allowed)
            d=rng.uniform(L,U)
            s.append({'e':e,'e0':e0,'L':L,'U':U,'eta':eta,'delta_true_evaluator_only':d})
        self.assertTrue(verify_path(s)['bound_holds'])
    def test_false_coverage_rejected(self):
        with self.assertRaises(ValueError):
            verify_path([{'e':0,'e0':1,'L':-.2,'U':.1,'eta':1,'delta_true_evaluator_only':.4}])
    def test_invalid(self):
        with self.assertRaises(ValueError):safe_actions((0,1),.5,.2,-.2,.01)
        with self.assertRaises(ValueError):safe_actions((0,1),.5,-.2,.2,-.01)
if __name__=='__main__':unittest.main(verbosity=2)
