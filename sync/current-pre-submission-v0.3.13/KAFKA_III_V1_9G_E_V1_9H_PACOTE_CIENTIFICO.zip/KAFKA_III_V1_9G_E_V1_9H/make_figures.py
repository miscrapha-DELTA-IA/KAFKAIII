#!/usr/bin/env python3
"""Rebuild the signed paired-difference plot from stored CSVs; matplotlib is used only for plotting."""
from pathlib import Path
import csv
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parent
rows=[x for x in csv.DictReader((root/'paired_v1_9g.csv').open()) if x['comparator']=='markov_model_average_dp']
labels=[r['family'].replace('_',' ') for r in rows]
y=list(range(len(rows)))
v=[float(r['comparator_minus_kafka']) for r in rows]
lo=[float(r['mc_bonferroni_lower']) for r in rows]
hi=[float(r['mc_bonferroni_upper']) for r in rows]
fig,ax=plt.subplots(figsize=(10,10))
ax.errorbar(v,y,xerr=[[a-b for a,b in zip(v,lo)],[b-a for a,b in zip(v,hi)]],fmt='o',capsize=2)
ax.axvline(0,linestyle='--')
ax.set_yticks(y,labels)
ax.invert_yaxis()
ax.set_xlabel('Perda Bayes mistura − perda KAFKA (positivo favorece KAFKA)')
ax.set_title('KAFKA III v1.9G | Contrastes emparelhados: Bonferroni sobre 154')
ax.grid(axis='x',alpha=.2)
fig.tight_layout()
fig.savefig(root/'figure_bayes_mix_vs_kafka.png',dpi=180)
