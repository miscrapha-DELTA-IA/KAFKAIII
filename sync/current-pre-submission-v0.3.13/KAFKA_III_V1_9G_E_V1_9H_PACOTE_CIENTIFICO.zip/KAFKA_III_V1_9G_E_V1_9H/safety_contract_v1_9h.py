#!/usr/bin/env python3
"""Conditional baseline-relative safety kernel: analytic, not an original theorem or clinical guarantee.

Assume an already scientifically justified interval for the *future* causal effect
Delta of displaying vs withholding an alert. Valid only without interference and
when the policy does not modify those potential-outcome estimands.
"""
from __future__ import annotations


def loss(exposure:float,effect:float)->float:
    if not (0<=exposure<=1):raise ValueError('exposure outside [0,1]')
    return (1-exposure)*max(effect,0)+exposure*max(-effect,0)


def worst_relative_loss(exposure:float,baseline:float,lower:float,upper:float)->float:
    if not 0<=exposure<=1 or not 0<=baseline<=1 or lower>upper:
        raise ValueError('invalid policy or interval')
    return max((baseline-exposure)*lower,(baseline-exposure)*upper)


def safe_actions(actions,baseline:float,lower:float,upper:float,eta:float,tol:float=1e-12):
    if eta<0:raise ValueError('eta must be nonnegative')
    a=tuple(actions)
    if not a or any(x<0 or x>1 for x in a):raise ValueError('invalid action grid')
    return tuple(e for e in a if worst_relative_loss(e,baseline,lower,upper)<=eta+tol)


def guard_bayes_action(action_values:dict,baseline:float,lower:float,upper:float,eta:float):
    """Choose Bayesian or other score optimizer only among safe actions, fail closed if empty.

    The scores may be Bellman Q-values from any planner; this filter by itself does
    not confer confidence interval validity or prove novelty over safe policy learning.
    """
    allowed=safe_actions(action_values,baseline,lower,upper,eta)
    if not allowed: return None
    return min(allowed,key=lambda e:(action_values[e],abs(e-baseline),e))


def verify_path(steps):
    """Evaluator-only certificate; must not feed true effects into a controller.

    With correctly covered future effects and no unmodelled costs/interference:
    cumulative realized EXPECTED (not patient-level realized) loss vs reference
    is at most sum of per-period eta.
    """
    total=0.;budget=0.
    for s in steps:
        e,e0,L,U,eta,delta=(s[k] for k in ('e','e0','L','U','eta','delta_true_evaluator_only'))
        if not L<=delta<=U:raise ValueError('future effect not contained in envelope')
        if worst_relative_loss(e,e0,L,U)>eta+1e-12:
            raise ValueError('unsafe action')
        total += loss(e,delta)-loss(e0,delta)
        budget += eta
    return {'relative_expected_loss':total,'cumulative_degradation_bound':budget,
            'bound_holds':total<=budget+1e-12}
