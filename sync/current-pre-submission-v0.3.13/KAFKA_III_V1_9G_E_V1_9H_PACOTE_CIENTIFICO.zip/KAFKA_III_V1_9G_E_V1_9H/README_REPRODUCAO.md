# KAFKA III — v1.9G / v1.9H (12/11/2026)

## O que este pacote é
Desenvolvimento computacional interno **exploratório**, não pré-registro público, não teste independente, não prova de superioridade geral, não uso clínico. A nova política KAFKA temporal *não* superou os principais benchmarks dinâmicos no agregado exploratório das 22 famílias. Resultados positivos e negativos foram preservados integralmente.

## Conteúdo
- `PROTOCOL_BEFORE_RUN.md`: protocolo interno fixado antes da bateria principal com SHA-256 em `PROTOCOL_SHA256.txt`.
- `experiment_v1_9g.py`: gerador e comparador com oito políticas; parâmetros/famílias completos no código.
- `source_v1_9e/experiment_v1_9e.py`: código-fonte original preservado e importado para fórmulas e comparadores.
- `metrics_v1_9g.csv`: 22×8 linhas com perdas e outras métricas.
- `paired_v1_9g.csv`: 154 contrastes pareados, IC 95% MC marginais e Bonferroni descritivo.
- `audit_paths_v1_9g.csv`: cinco trajetórias exemplares por família/política (verdade latente **somente do avaliador**).
- `execution_manifest.json`: sementes, versão, hash do protocolo, amostras e verificações.
- `safety_contract_v1_9h.py`: restrição condicional de prejuízo em relação à referência. NÃO foi usado nos resultados v1.9G.
- `test_v1_9g.py`, `test_safety_contract_v1_9h.py`: 12+7 testes unitários; logs correspondentes.
- `RELATORIO_V1_9G_E_PLANO_V1_9H.pdf` e `.md`: análise e proposta de próxima etapa.
- `MANUSCRIPT_ADDENDUM_V1_9G_EN.md`: suplemento em inglês para possível revisão editorial, **não confirmatório**.
- `figure_bayes_mix_vs_kafka.png`, `make_figures.py`, `build_report.py`: figura e relatório regeneráveis.
- `manifest_sha256.txt`: hashes do conteúdo entregue.

## Reprodução
Requer Python >=3.10, biblioteca padrão apenas para os experimentos. Dentro desta pasta:

```bash
python test_v1_9g.py
python test_safety_contract_v1_9h.py
python experiment_v1_9g.py
```

O script sobrescreve os três CSVs de resultados e o manifesto de execução usando sementes especificadas. O objetivo é igualdade das linhas em máquinas com Python compatível; resultados matemáticos podem mudar minimamente se houver diferenças de aritmética de ponto flutuante. Rodar uma nova bateria não reclassifica as evidências como confirmatórias.

Para o PDF/figura, dependências opcionais: matplotlib, pandoc, xelatex e fontes DejaVu; `python make_figures.py`, `python build_report.py`, e pandoc com PDF engine xelatex.

## Bloqueadores científicos
Faltam: dados de efeitos identificados randomizando exibição do alerta (quando permitido e eticamente aprovado), intervalos válidos para efeitos futuros, tratamento do desfecho censurado/MNAR com hipóteses, efeito de interferência entre unidades, baseline seguro histórico exato no *mesmo* simulador, POMDP minimax multietapas forte, avaliador externo cego e margens clínicas legitimadas. Não usar este pacote para decisões de saúde.
