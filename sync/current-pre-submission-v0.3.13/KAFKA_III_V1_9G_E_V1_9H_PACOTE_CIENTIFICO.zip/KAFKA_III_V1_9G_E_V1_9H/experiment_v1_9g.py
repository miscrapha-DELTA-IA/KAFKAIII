#!/usr/bin/env python3
"""KAFKA III v1.9G: internally pre-specified exploratory temporal benchmark.
Not clinical, causal inference, independent validation or a robust-POMDP proof.
Depends only on Python stdlib and the preserved v1.9E experiment module in ../source_v1_9e/.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from functools import lru_cache
from pathlib import Path
import csv, importlib.util, json, math, random, statistics, sys, hashlib

ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'source_v1_9e'))
import experiment_v1_9e as old

N=800
SEED0=20261112
SEED_STEP=1319
H=6
# Markov additions are postulated ex ante, not selected from observations.
@dataclass(frozen=True)
class MarkovFamily:
    name:str
    hazard:float
    initial_prior:float=.42
    accuracy:float=.85
    dynamic:bool=False

FAMILIES=tuple(old.FAMILIES)+(
    MarkovFamily('markov_switch_08',.08),
    MarkovFamily('markov_switch_20',.20),
    MarkovFamily('markov_switch_40',.40),
    MarkovFamily('markov_hazard_shift_05_to_45',.05,dynamic=True),
)
POLICIES=('kafka_gate_e','nominal_static_dp','static_accuracy_mix_dp',
          'markov_dp_h20','markov_model_average_dp','kafka_temporal_guard',
          'dynamic_worst_model','safe_static_proxy_e')
KAFKA='kafka_temporal_guard'


def tup(w):
    # Discretization to stabilize cache keys. Error on posterior probabilities <1e-10 per element.
    return tuple(round(float(x),10) for x in w)

class MarkovBeliefDP:
    def __init__(self, models, mixing=None):
        self.models=tuple(models)
        self.mixing=tuple(mixing if mixing is not None else [1/len(models)]*len(models))
        assert len(self.models)==len(self.mixing) and abs(sum(self.mixing)-1)<1e-8
        self.w0=tup(v for mix in self.mixing for v in (mix*old.PRIOR,mix*(1-old.PRIOR)))

    def probability(self,w):
        return sum(w[::2])/sum(w)

    def separate(self,w):
        vals=[]
        for i, (haz,acc) in enumerate(self.models):
            z=w[2*i]+w[2*i+1]
            vals.append((w[2*i]/z if z>1e-14 else .5,z))
        return vals

    def pos_signal_probability(self,w):
        return sum(w[2*i]*acc+w[2*i+1]*(1-acc)
                   for i,(haz,acc) in enumerate(self.models))/sum(w)

    def update(self,w,positive):
        raw=[]
        for i,(haz,acc) in enumerate(self.models):
            raw.extend((w[2*i]*(acc if positive else 1-acc),
                        w[2*i+1]*((1-acc) if positive else acc)))
        z=sum(raw)
        if z==0: return w
        return tup(v/z for v in raw)

    def predict(self,w):
        new=[]
        for i,(haz,acc) in enumerate(self.models):
            p,m=w[2*i],w[2*i+1]
            new.extend(((1-haz)*p+haz*m,haz*p+(1-haz)*m))
        return tup(new)

    def forward(self,t,events):
        # Observations are located at source cohort time, even when late.
        w=self.w0
        for src in range(t):
            if src in events:
                w=self.update(w,events[src])
            w=self.predict(w)
        return w

    def instant(self,w,e):
        p=self.probability(w)
        return old.EFFECT*(p*(1-e)+(1-p)*e)+old.ACQ_COST*old.q_of(e,.02,.82)

    def value_action(self,h,w,b,e):
        if old.is_probe(e) and b==0:return math.inf
        out=self.instant(w,e)
        if h==1:return out
        budget=b-int(old.is_probe(e))
        q=old.q_of(e,.02,.82)
        a=self.pos_signal_probability(w)
        # Outcome acquired at cohort t, delivered before next decision.
        return out+(1-q)*self.value(h-1,self.predict(w),budget)+q*(
            a*self.value(h-1,self.predict(self.update(w,True)),budget)
            +(1-a)*self.value(h-1,self.predict(self.update(w,False)),budget))

    @lru_cache(maxsize=100000)
    def value(self,h,w,b):
        if not h:return 0.0
        return min(self.value_action(h,w,b,e) for e in old.GRID
                   if b>0 or not old.is_probe(e))

    def decide(self,h,w,b,allowed):
        assert allowed
        return min(allowed,key=lambda e:(round(self.value_action(h,w,b,e),11),e))


H20=MarkovBeliefDP(((.20,.85),))
MIX=MarkovBeliefDP(tuple((h,a) for h in (0,.20,.40) for a in (.55,.85)))


def worst_model(w,e):
    vals=MIX.separate(w)
    populated=[p for p,weight in vals if weight>=.04]
    if not populated:
        populated=[MIX.probability(w)]
    return max(old.EFFECT*(p*(1-e)+(1-p)*e) for p in populated)+old.ACQ_COST*old.q_of(e,.02,.82)


def select_new(policy,t,b,w,allowed):
    if policy=='markov_dp_h20':return H20.decide(H-t,w,b,allowed)
    if policy=='markov_model_average_dp':return MIX.decide(H-t,w,b,allowed)
    if policy=='dynamic_worst_model':return min(allowed,key=lambda e:(round(worst_model(w,e),11),e))
    assert policy==KAFKA
    base=MIX.decide(H-t,w,b,allowed)
    vals=MIX.separate(w)
    populated=[p for p,weight in vals if weight>=.04]
    if not populated:populated=[MIX.probability(w)]
    # Gate applies only to extreme authority choices; fractions .25,.5,.75 are probes.
    if (base<.25 and max(populated)<.30) or (base>.75 and min(populated)>.70):
        return base
    if .5 in allowed and b>0:
        return .5
    return min(allowed,key=lambda e:(round(worst_model(w,e),11),e))


def generate(env,rep,rng):
    p=env.initial_prior if isinstance(env,MarkovFamily) else env.true_prior
    latent=1 if rng.random()<p else -1
    returns=[tuple(rng.random() for _ in range(4)) for _ in range(H)]
    thetas=[]
    state=latent
    for t in range(H):
        if isinstance(env,MarkovFamily):
            if t:
                hazard=env.hazard if not env.dynamic or t<3 else .45
                if returns[t][3] <hazard:state=-state
            thetas.append(state)
        else:
            thetas.append(old.theta_for(env,latent,t,rep))
    return thetas,returns


def simulate(env,policy,thetas,returns):
    new=policy in ('markov_dp_h20','markov_model_average_dp',KAFKA,'dynamic_worst_model')
    engine=H20 if policy=='markov_dp_h20' else MIX
    legacy_model=old.ROBUST if policy=='static_accuracy_mix_dp' else old.NOMINAL
    legacy_w=legacy_model.w0
    evidence={}
    pending=[]
    gov=old.Gov()
    budget=old.PROBE_BUDGET
    last_source=None
    count=0
    losses={'total':0.,'biological':0.,'acquisition':0.,'review':0.,'congestion':0.,
            'probes':0,'signals':0,'wrong_high':0,'wrong_low':0,'contingency':0,
            'uninformative':0,'late_signals':0}
    actions=[]
    for t in range(H):
        due=[(src,s) for when,src,s in pending if when<=t]
        pending=[item for item in pending if item[0]>t]
        for src,sig in due:
            if src in evidence:raise AssertionError('Duplicate evidence source')
            evidence[src]=sig
            legacy_w=legacy_model.signal(legacy_w,sig)
            count+=1
            last_source=src
            losses['signals']+=1
        if new:
            w=engine.forward(t,evidence)
        else:
            w=legacy_w
        if isinstance(env,MarkovFamily):
            lo,hi=(0.,1.)
            permission=t>=1
            signed=False
        else:
            lo,hi=old.bounds_for(env,t)
            permission=old.reentry_authorized(env,t)
            signed=old.signed_release(env,t)
        blocked,fee,_=gov.check(lo,hi,signed)
        losses['review']+=fee
        if blocked:
            e=.1;contingency=True
        else:
            legal,_=old.allowed_regular(lo,hi,budget)
            if not legal:
                losses['review']+=gov.force_review()
                e=.1;contingency=True
            else:
                if new:
                    e=select_new(policy,t,budget,w,legal)
                else:
                    oldname={'kafka_gate_e':'kafka_gate',
                             'nominal_static_dp':'nominal_bayes',
                             'static_accuracy_mix_dp':'robust_bayes_mix',
                             'safe_static_proxy_e':'safe_static_proxy'}[policy]
                    e=old.select_policy(oldname,t,H-t,budget,w,last_source,count,legal,permission)
                assert e in legal and lo<=e<=hi
                contingency=False
                if old.is_probe(e):
                    budget-=1
                    losses['probes']+=1
        if contingency:
            losses['contingency']+=1
        assert budget>=0
        theta=thetas[t]
        q=0. if contingency else old.q_of(e,env.q0,env.qmax) if isinstance(env,old.Environment) else old.q_of(e,.02,.82)
        bio=old.clinical_loss(theta,e)
        losses['biological']+=bio
        losses['acquisition']+=old.ACQ_COST*q
        kappa=env.kappa if isinstance(env,old.Environment) else 0.
        losses['congestion']+=kappa*e*e
        losses['wrong_high']+=int(theta==-1 and e>=.75)
        losses['wrong_low']+=int(theta==1 and e<=.25)
        losses['uninformative']+=int(t>0 and count==0)
        actions.append(e)
        uacq,umiss,usig,_=returns[t]
        if uacq<q:
            if isinstance(env,old.Environment):
                drop=env.drop_plus if theta==1 else env.drop_minus if theta==-1 else .50
                accuracy=old.accuracy_for(env,t) if theta else .5
                delay=env.delay
            else:
                drop=0.;accuracy=env.accuracy;delay=0
            if umiss>=drop:
                signal=usig<(accuracy if theta==1 else 1-accuracy if theta==-1 else .5)
                arrival=t+1+delay
                pending.append((arrival,t,signal))
                if arrival>=H:losses['late_signals']+=1
    losses['total']=sum(losses[x] for x in ('biological','acquisition','review','congestion'))
    assert losses['probes']<=2 and not (losses['contingency'] and losses['probes']>2)
    return losses,actions


def mean_se(xs):
    return statistics.mean(xs),statistics.stdev(xs)/math.sqrt(len(xs)) if len(xs)>1 else 0


def dump_csv(name,rows):
    with (ROOT/name).open('w',newline='',encoding='utf8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def run(n=N):
    summary=[];pairs=[]; per_episode=[];all_checks={}
    for fi,env in enumerate(FAMILIES):
        rng=random.Random(SEED0+SEED_STEP*fi)
        data={policy:[] for policy in POLICIES}
        for rep in range(n):
            thetas,returns=generate(env,rep,rng)
            for policy in POLICIES:
                losses,acts=simulate(env,policy,thetas,returns)
                data[policy].append(losses)
                if rep<5:
                    per_episode.append({'family':env.name,'rep':rep,'policy':policy,
                                        'theta_evaluator_only':str(thetas),'exposures':str(acts),
                                        'loss':round(losses['total'],9)})
        for policy in POLICIES:
            avg,se=mean_se([x['total'] for x in data[policy]])
            row={'family':env.name,'policy':policy,'n':n,
                 'mean_loss':round(avg,9),'mc_se':round(se,9)}
            for k in ('biological','acquisition','review','congestion','probes','signals',
                      'wrong_high','wrong_low','contingency','uninformative','late_signals'):
                row['mean_'+k]=round(statistics.mean(x[k] for x in data[policy]),8)
            summary.append(row)
        for comp in POLICIES:
            if comp==KAFKA:continue
            vals=[x['total']-y['total'] for x,y in zip(data[comp],data[KAFKA])]
            avg,se=mean_se(vals)
            # Family-wise max 154 pairwise contrasts: conservative Bonferroni normal quantile.
            # 1-alpha/(2*154) => z ~3.6, compute exact via statistics.NormalDist.
            z=statistics.NormalDist().inv_cdf(1-.05/(2*(len(FAMILIES)*(len(POLICIES)-1))))
            pairs.append({'family':env.name,'comparator':comp,'n':n,
                'comparator_minus_kafka':round(avg,9),'se_paired':round(se,9),
                'mc95_lower':round(avg-1.96*se,9),'mc95_upper':round(avg+1.96*se,9),
                'mc_bonferroni_lower':round(avg-z*se,9),'mc_bonferroni_upper':round(avg+z*se,9)})
        all_checks[env.name]={'n':n,'policies':len(POLICIES),'mean_wins_vs_baselines':sum(
          statistics.mean(x['total'] for x in data[c])>
          statistics.mean(x['total'] for x in data[KAFKA]) for c in POLICIES if c!=KAFKA)}
        print(f'{fi+1:2}/{len(FAMILIES)} {env.name} KAFKA={statistics.mean(x["total"] for x in data[KAFKA]):.5f} '
              f'mix={statistics.mean(x["total"] for x in data["markov_model_average_dp"]):.5f}',flush=True)
    dump_csv('metrics_v1_9g.csv',summary)
    dump_csv('paired_v1_9g.csv',pairs)
    dump_csv('audit_paths_v1_9g.csv',per_episode)
    result={'version':'1.9G','status':'internal, exploratory, non-clinical','N':n,
            'families':len(FAMILIES),'policies':list(POLICIES),'pairs':len(pairs),
            'protocol_sha256':hashlib.sha256((ROOT/'PROTOCOL_BEFORE_RUN.md').read_bytes()).hexdigest(),
            'checks':all_checks,
            'model_mix':MIX.models,'seed0':SEED0,'seed_step':SEED_STEP}
    (ROOT/'execution_manifest.json').write_text(json.dumps(result,indent=2),encoding='utf8')
    return result

if __name__=='__main__':
    assert len(FAMILIES)==22 and len(POLICIES)==8
    run()
