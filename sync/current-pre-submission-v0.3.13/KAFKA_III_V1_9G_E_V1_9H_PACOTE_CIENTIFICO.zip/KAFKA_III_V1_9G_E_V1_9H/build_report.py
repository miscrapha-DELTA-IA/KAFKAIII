from pathlib import Path
from collections import defaultdict
import csv,statistics,hashlib,json,datetime
ROOT=Path(__file__).resolve().parent
r=list(csv.DictReader((ROOT/'metrics_v1_9g.csv').open()))
p=list(csv.DictReader((ROOT/'paired_v1_9g.csv').open()))
policies=['kafka_gate_e','nominal_static_dp','static_accuracy_mix_dp','markov_dp_h20','markov_model_average_dp','dynamic_worst_model','safe_static_proxy_e']
k='kafka_temporal_guard'
families=list(dict.fromkeys(x['family'] for x in r))
lookup={(x['family'],x['policy']):x for x in r}
plookup={(x['family'],x['comparator']):x for x in p}
assert len(families)==22 and len(p)==154 and all(x['n']=='800' for x in p)
win={b:sum(float(plookup[f,b]['comparator_minus_kafka'])>0 for f in families) for b in policies}
sigwin={b:sum(float(plookup[f,b]['mc_bonferroni_lower'])>0 for f in families) for b in policies}
siglose={b:sum(float(plookup[f,b]['mc_bonferroni_upper'])<0 for f in families) for b in policies}
focus=plookup['benefit_to_harm','markov_model_average_dp']

def ff(x):return f'{float(x):.4f}'
lines=[]
lines.append('---\ntitle: "KAFKA III — Auditoria de desenvolvimento v1.9G e contrato de segurança v1.9H"\nsubtitle: "Resultados de falsificação, limites da superioridade e plano de redesenho"\nauthor: "Relatório técnico interno — autoria científica a definir"\ndate: "12 de novembro de 2026"\nlang: pt-BR\ngeometry: margin=2.0cm\nfontsize: 10pt\nmainfont: DejaVu Sans\n---\n')
lines.append('> **CLASSIFICAÇÃO:** experimentação inteiramente sintética, exploratória, executada e examinada internamente. Não é ensaio clínico, pré-registro público, prova de efeito causal, protocolo regulatório ou validação independente. \n')
lines.append('## Síntese executiva\n')
lines.append(f'Foram simuladas **22 famílias × 8 políticas × 800 trajetórias = {22*8*800:,} trajetórias**, cada uma com seis decisões sintéticas; 19 testes unitários novos foram executados (12 da v1.9G e 7 do filtro v1.9H). O experimento manteve os cenários originais adversariais da v1.9E e adicionou quatro famílias Markov predefinidas. Todos os resultados — inclusive os negativos — estão nos CSVs. A regra candidata `kafka_temporal_guard` **não atingiu superioridade global** e não superou o melhor comparador em nenhuma das 22 famílias por média amostral.\n'.replace('140,800','140.800'))
lines.append('No cenário `benefit_to_harm`, a regra KAFKA obteve perda média **'+ff(lookup['benefit_to_harm',k]['mean_loss'])+'** versus **'+ff(lookup['benefit_to_harm','markov_model_average_dp']['mean_loss'])+'** para o planejador de mistura dinâmica. A diferença favorável foi **'+ff(focus['comparator_minus_kafka'])+'**, IC Monte Carlo Bonferroni 154 contrastes **['+ff(focus['mc_bonferroni_lower'])+'; '+ff(focus['mc_bonferroni_upper'])+']**. Esse resultado positivo é estritamente local ao cenário e não repara os resultados negativos de outras famílias.\n')
lines.append('### Descoberta central\n')
lines.append('O mecanismo de exigir consenso entre modelos antes de confiar em exposição extrema teve custo elevado em vários cenários. Uma melhor arquitetura KAFKA não deve converter automaticamente discordância posterior em sondagem ou suspensão, nem substituir planejamento dinâmico por veto heurístico; precisa incorporar uma **restrição verificável de deterioração frente à referência**, otimizar o valor da informação dentro das ações protegidas e estimar o efeito causal da exibição com desenho identificável.\n')
lines.append('## 1. Contrato experimental da v1.9G\n')
lines.append('- **Observação:** sinal binário de um gerador abstrato; seu mecanismo não equivale a ensaio clínico randomizado. A probabilidade de receber sinal `q(e)=0,02 + 4(0,82−0,02)e(1−e)` é positiva mesmo em exposição 0 ou 1, impossibilitando interpretar esse canal como uma comparação causal identificada por dois braços nesses extremos.\n- **Estados:** efeito latente sintético −0,1, 0 ou +0,1; o estado verdadeiro é visível só ao avaliador. As quatro famílias adicionais incluem hazard de alternância 0,08, 0,20, 0,40 e mudança 0,05 para 0,45.\n- **Ações e custos:** mesma grade, orçamento máximo de duas ações intermediárias, contingência no conflito de permissões, custo de aquisição, congestionamento proxy e revisão. As ações possíveis são as mesmas para as oito políticas; o gate extra é escolhido **apenas** pelo candidato KAFKA.\n- **História:** coorte da observação preservada quando o sinal chega tarde; filtros dinâmicos são reconstruídos com timestamps, mas os planejadores antecipam observação em t+1. O planejador de mistura não é solução de POMDP robusto minimax.\n- **Estatística:** contrastes pareados por uniformes exógenos compartilhados; intervalos MC normais descritivos, com uma correção Bonferroni para 154 contrastes (22 famílias × 7 comparadores). Nem essa correção nem a data do protocolo criam avaliação cega.\n')
lines.append('### Comparadores\n')
for name,desc in [
 ('nominal_static_dp','Bellman exato dentro do modelo de efeito estático e acurácia 0,85'),
 ('static_accuracy_mix_dp','Bellman exato dentro da mistura estática de acurácia 0,55/0,85'),
 ('markov_dp_h20','Bellman de um modelo de alternância de sinal com hazard 0,20 e acurácia 0,85'),
 ('markov_model_average_dp','Bellman da mistura de hazard (0/0,20/0,40) e acurácia (0,55/0,85)'),
 ('dynamic_worst_model','minimax imediato entre filtros ponderados; não é minimax POMDP multietapas'),
 ('kafka_gate_e','regra histórica KAFKA simplificada da v1.9E'),
 ('safe_static_proxy_e','exposição conservadora proxy, NÃO o safe policy learning da v1.8A')]:
 lines.append(f'- `{name}`: {desc}.')
lines.append('\n## 2. Resultados completos, 22 famílias\n')
lines.append('Menor perda é melhor. Escala sintética acumulada, sem calibração clínica.\n')
lines.append('| Família | KAFKA temporal | Bayes nominal | Bayes Markov 0,20 | Bayes mistura Markov |')
lines.append('|:---|---:|---:|---:|---:|')
for f in families:
 short={
   'reverse_after_reentry_window':'reversao_dupla',
   'heterogeneity_two_strata':'dois_estratos',
   'informative_missingness':'censura_MNAR',
   'cluster_congestion_proxy':'congestao_proxy',
   'markov_hazard_shift_05_to_45':'Markov_hazard_shift',
   'governance_conflict':'conflito_governanca',
   'drifting_accuracy':'drift_acuracia',
 }.get(f,f)
 lines.append('| `'+short+'` | '+ ' | '.join(ff(lookup[f,p]['mean_loss']) for p in [k,'nominal_static_dp','markov_dp_h20','markov_model_average_dp'])+' |')
lines.append('\nOs nomes completos e sem abreviações de todas as famílias estão nos arquivos CSV de resultados.\n')
lines.append('\n### Confronto com cada comparador\n')
lines.append('| Comparador | Famílias em que KAFKA tem menor média (de 22) | Bonferroni 154: favorecem KAFKA | Bonferroni 154: favorecem comparador |')
lines.append('|:---|---:|---:|---:|')
for b in policies:
 lines.append(f'| `{b}` | {win[b]} | {sigwin[b]} | {siglose[b]} |')
lines.append('\nOs 154 contrastes completos, sem descartar falhas, estão em `paired_v1_9g.csv`. Os limites Bonferroni são para incerteza **de Monte Carlo sob este simulador**, não intervalos causais nem cobertura robusta a seleção de métodos/cenários. A escolha do melhor comparador após observar resultados deve ser entendida somente como diagnóstico.\n')
lines.append('![Contrastes pareados: diferença de perda Bayes mistura − KAFKA temporal, com IC Monte Carlo Bonferroni 154.](figure_bayes_mix_vs_kafka.png){ width=88% }\n')
lines.append('## 3. Por que a superioridade ampla continua bloqueada\n')
lines.append('1. **Ótimo nominal:** no modelo correto, com as mesmas informações, custos e direitos, a política Bayes ótima minimiza perda esperada. Uma regra distinta não pode ter desempenho esperado melhor sob exatamente esse modelo e a mesma função objetivo.\n2. **Custo da prudência:** forçar exposição 0,5 sob discordância reduz exposição extrema, mas gasta orçamento e pode aumentar o arrependimento no benefício persistente.\n3. **Efeito de informação:** ações mudam a observabilidade; suspensão por evidência insuficiente pode agravar a própria insuficiência de evidência.\n4. **Inversão de sinal:** sem âncora independente, inverter o canal pode tornar o efeito e a evidência observada indistinguíveis. “Mais confiança” não corrige rótulos invertidos.\n5. **Comparação incompleta:** nem a v1.9E nem a v1.9G implementaram uma revisão clínica, um estimando causal de exibição observado ou o seguro `safe policy learning` histórico exato no mesmo ambiente.\n6. **Sem autonomia para autorização clínica:** assinatura, direitos de exposição e custos humanos devem ser definidos exogenamente por governança humana.\n')
lines.append('## 4. Novo núcleo matemático recomendado para v1.9H\n')
lines.append('O núcleo não deve tentar reinventar `safe policy learning`. Ele pode usá-lo como **camada verificável e comum** de proteção, depois otimizar planejamento dinâmico auditável dentro do espaço admissível.\n')
lines.append('Se `Δ_t = E[Y_t(1)−Y_t(0)]` é o efeito causal *futuro* da exibição para uma população elegível e a perda é `loss(e,Δ)=(1−e)max(Δ,0)+e max(−Δ,0)`, então, sem interferência e para o mesmo efeito fixo dentro do período:\n')
lines.append('$$\\ell(e,\\Delta)-\\ell(e_0,\\Delta)=(e_0-e)\\Delta.$$\n')
lines.append('Para um conjunto **legítimo e prospectivo** `Θ_t=[L_t,U_t]` e tolerância externa `η_t≥0`, definimos ações seguras:\n')
lines.append('$$\\mathcal E_t^{\\rm safe}=\\left\\{e\\in\\mathcal E_t: \\max_{\\delta\\in[L_t,U_t]}(e_{0,t}-e)\\delta\\leq\\eta_t\\right\\}.$$\n')
lines.append('Se, em todos os períodos, o efeito futuro verdadeiro realmente pertence a `Θ_t`, cada decisão é escolhida nesse conjunto e os custos extraordinários foram controlados separadamente, o excesso de **perda esperada** sobre a referência é limitado por `Ση_t`. A prova é somar as desigualdades anteriores. Quando o limite futuro não é válido, a garantia desaparece; quando há interferência, os estimandos precisam ser definidos para regimes hospitalares. A proposição é elementar e **não reivindicada como inédita**.\n')
lines.append('O arquivo `safety_contract_v1_9h.py` contém um filtro de ações e um verificador apenas para o avaliador, com 7 testes. O filtro falha explicitamente (`None`) quando o conjunto seguro é vazio, em vez de forçar ação regular. **Esse arquivo não foi usado para reotimizar os resultados da v1.9G.**\n')
lines.append('## 5. Próximo experimento realmente discriminante\n')
lines.append('### Fase A — identificação causal (pré-condição)\n')
lines.append('- Definir população elegível antes da decisão, `Z` exibição de recomendação, `T` tratamento, `D` decisão, `Y` desfecho verdadeiro, `C_obs` registro. Estimando primário: intenção de tratar da **exibição** `Δ_Z,t`, sem confundi-lo com efeito biológico do tratamento ou efeito de implantar o sistema.\n- Substituir o sinal abstrato da v1.9G por alocação randomizada com propensão registrada em dois braços quando eticamente permitida, atraso de desfecho e censura com hipótese identificável/sensibilidade. A ausência de contraste entre braços implica estado de **não identificação**, não atualização artificial.\n- Calibrar custo de alerta, dano por supressão, sobrecarga e autonomia com especialistas e avaliação ética, em vez de escolher pesos para ganhar simulações.\n')
lines.append('### Fase B — arquitetura competitiva KAFKA III\n')
lines.append('- Motor de inferência causal: estimador com propensity logging, pré-especificação de intervalos sob observabilidade adequada, correção/limites para não observação e relógio de coorte.\n- Motor de planejamento: POMDP Bayes com mudança temporal, incerteza sobre transição e observação, aquisição e atraso; mesmo otimizador de referência para todos os métodos.\n- Camada de autoridade: limite externo de deterioração em relação ao cuidado de referência, validade temporal da evidência, contingência fora da decisão regular, auditoria de todas as decisões, com autorização exógena.\n- Separar política operacional de estado administrativo: a revisão não cria novas observações nem identifica causalidade; não tratar o gate de reentrada autoimposto como veto legal aos concorrentes.\n')
lines.append('### Fase C — validação e critérios de avanço\n')
lines.append('- Registrar publicamente estimando, permissões idênticas, perdas, margens, cenários e critérios de vitória *antes* de entregar dados/sementes finais a avaliador cego.\n- Incluir baselines de mesma classe: safe policy learning equivalente à v1.8A no ambiente causal, Bayes corretamente especificado, Bayes com incerteza paramétrica e robust POMDP/minimax multietapas real; manter sempre ligado/desligado e sentinela.\n- **Critério de vitória:** diferença positiva de perda (comparador − KAFKA) em família relevante previamente definida, com correção de múltiplos testes; nenhuma violação do limite de segurança acordado em famílias falsificadoras; resultados independentes e reproduzíveis.\n- Se o ganho não superar alternativas de mesma classe, não alegar superioridade: publicar os resultados de limite/decisão e negativos.\n')
lines.append('## 6. Integridade e reprodutibilidade\n')
lines.append(f'- Documento de protocolo preservado com SHA-256: `{hashlib.sha256((ROOT/"PROTOCOL_BEFORE_RUN.md").read_bytes()).hexdigest()}`. Isso fornece trilha interna, **não** pré-registro independente.\n')
lines.append('- 12 testes de motor/filtro v1.9G aprovados; 7 testes adicionais de segurança v1.9H aprovados. Código v1.9E de origem incluso para reconstrução.\n- Conjuntos `metrics_v1_9g.csv` (22×8), `paired_v1_9g.csv` (22×7), `audit_paths_v1_9g.csv` (cinco episódios por família e política, com estados `theta_evaluator_only`), `execution_manifest.json`, `run_v1_9g.log` e logs de teste estão no pacote.\n- Execução: `python test_v1_9g.py`; `python test_safety_contract_v1_9h.py`; `python experiment_v1_9g.py`. A simulação original v1.9E permanece arquivada e não foi modificada.\n')
lines.append('## 7. Antecedentes que limitam reivindicações de novidade\n')
lines.append('- Joshi, Zhang & Bareinboim (2024), *Towards Safe Policy Learning under Partial Identifiability: A Causal Approach*, AAAI. https://ojs.aaai.org/index.php/AAAI/article/view/29198\n- Ben-Michael, Greiner, Imai & Jiang (2025), *Safe Policy Learning through Extrapolation*, JASA. https://imai.fas.harvard.edu/research/files/safe.pdf\n- Galesloot et al. (2025), *Robust Finite-Memory Policy Gradients for Hidden-Model POMDPs*, IJCAI. https://ijcai.org/proceedings/2025/947\n- Galesloot et al. (2026), *Pessimistic Iterative Planning with RNNs for Robust POMDPs*, ECAI. https://journals.sagepub.com/doi/10.3233/FAIA251391\n- Li & Xiang (2025/2026), *Distributionally Robust Partially Observable Markov Decision Process with Distance-Based Ambiguity Sets*, IISE Transactions. https://doi.org/10.1080/24725854.2025.2505980\n')
lines.append('## Parecer final\n')
lines.append('**NÃO HÁ SUPERIORIDADE GERAL DEMONSTRADA.** A v1.9G aumenta o rigor ao acrescentar planejadores com mudança temporal e publicar falhas, mas mostra que o gate de consenso é excessivamente conservador. O progresso substantivo é a direção v1.9H: alinhar identificação causal, segurança condicional verificável e POMDP forte, sem manipular funções de perda ou excluir ambientes desfavoráveis. Os resultados da v1.9G devem figurar como suplemento negativo de desenvolvimento, não ser adicionados ao preprint como confirmação de eficácia.\n')
(ROOT/'RELATORIO_V1_9G_E_PLANO_V1_9H.md').write_text('\n'.join(lines),encoding='utf8')
# English manuscript addendum for future independent review.
addendum=f'''# Supplementary developmental analysis: KAFKA III v1.9G (12 November 2026)

**Status:** internal, exploratory and synthetic. This addendum was written after observing the reported results; it is not a pre-registered confirmatory analysis. It must not replace the original negative results or claim superiority over existing safe policy learning methods.

We investigated whether a temporally aware authority gate could reduce regret under possible latent-effect changes. The experiment used 22 synthetic environments, 8 policies, 800 paired episodes per environment, and six decisions per episode (140,800 policy trajectories). We preserved the first 18 generators from version 1.9E and added four stochastic Markov-switching families. The shared exposure set was {{0, .25, .5, .75, 1}} with no more than two intermediate-exposure periods. The observation channel remains an **abstract synthetic signal** and does not identify the causal effect of displayed clinical alerts; the q0=.02 nonzero signal rate at extreme exposure makes this limitation particularly salient.

The new KAFKA temporal gate employed Bayesian model averaging over switching hazards {{0, .2, .4}} and sensor accuracies {{.55, .85}}, followed by a model-consensus gate for extreme exposure. Controls included static nominal Bayesian dynamic programming, static accuracy mixture dynamic programming, switching Markov dynamic programming (hazard .2), model-average Markov dynamic programming, a myopic worst-model rule, the previous KAFKA gate and a conservative static proxy. The model-average planner is Bayesian-optimal **within the specified static model-mixture class with one-period signal maturation and numerical rounding**, not a robust POMDP minimax optimum. The Markov filters reconstruct delayed evidence at its original cohort timestamp.

The KAFKA temporal gate yielded smaller average simulated loss than the dynamic model-average Bayes comparator in {win['markov_model_average_dp']} of the 22 families, and smaller loss than the correctly specified Markov-hazard .2 planner in {win['markov_dp_h20']} families. It did not have the smallest observed mean loss among all eight methods in any family. In the `benefit_to_harm` generator, KAFKA averaged {ff(lookup['benefit_to_harm',k]['mean_loss'])} loss versus {ff(lookup['benefit_to_harm','markov_model_average_dp']['mean_loss'])} for the Bayesian model average; the paired comparator-minus-KAFKA difference was {ff(focus['comparator_minus_kafka'])}, with a descriptively adjusted 95% Monte Carlo Bonferroni interval [{ff(focus['mc_bonferroni_lower'])}, {ff(focus['mc_bonferroni_upper'])}] across 154 prespecified family-comparator contrasts. Other environments showed material harm from overcautious gating, notably persistent harm, harm-to-benefit reversal, and the Markov switching families. These Monte Carlo intervals describe simulation noise only; they do not account for earlier research iteration, structural uncertainty, or clinical transportability.

The exercise does not establish KAFKA's incremental methodological superiority. In particular, a Bayesian optimizer cannot be uniformly beaten under the same correctly specified model, actions, information, and expected-loss criterion. We therefore recommend decoupling (i) *causal evidence identification*, (ii) *dynamic information-aware planning*, and (iii) *baseline-relative safety constraints*. A conditional safety frontier defined by `max_{{delta in [L_t,U_t]}} (e0_t - e_t)*delta <= eta_t` gives a simple bound on cumulative expected regret relative to reference exposure whenever all future effects lie in their defensible envelopes, with no interference and separate accounting of operational costs. This is a standard consequence of baseline-relative policy learning, not a novel theorem.

The full 22-family table, 154 paired contrasts, 19 new tests, protocol hash, and source code are included in the v1.9G/v1.9H technical archive. Any superiority evaluation must next use an identified alert-display estimand and an independent prospective benchmark with the same authorization and safety constraints for all methods.\n'''
(ROOT/'MANUSCRIPT_ADDENDUM_V1_9G_EN.md').write_text(addendum,encoding='utf8')
print('wrote reports',len(lines))
