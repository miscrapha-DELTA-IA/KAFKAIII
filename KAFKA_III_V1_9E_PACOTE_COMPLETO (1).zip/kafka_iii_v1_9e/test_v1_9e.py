#!/usr/bin/env python3
"""Independent test definitions for v1.9E engine; standard library unittest."""
import csv, inspect, json, math, random, unittest
from pathlib import Path
import experiment_v1_9e as x

ROOT=Path(__file__).resolve().parent

class TestKAFKAv19E(unittest.TestCase):
    def test_design_frozen_matrix(self):
        self.assertEqual(len(x.FAMILIES),18)
        self.assertEqual(len(x.POLICIES),9)
        self.assertEqual(x.N,800)
        self.assertEqual(x.PROBE_BUDGET,2)
        self.assertEqual(x.H,6)
        self.assertEqual(len(set(e.name for e in x.FAMILIES)),18)

    def test_q_positivity_and_monotonic_symmetry(self):
        for e in (0,.1,.25,.5,.75,.9,1):
            q=x.q_of(e,.02,.82)
            self.assertGreaterEqual(q,.02)
            self.assertLessEqual(q,.82+1e-12)
            self.assertAlmostEqual(q,x.q_of(1-e,.02,.82))
        self.assertAlmostEqual(x.q_of(.5,.02,.82),.82)
        self.assertAlmostEqual(x.q_of(0,.02,.82),.02)

    def test_posterior_normalization_and_direction(self):
        for model in (x.NOMINAL,x.ROBUST):
            w=model.w0
            self.assertAlmostEqual(sum(w),1)
            pos=model.signal(w,True)
            neg=model.signal(w,False)
            self.assertAlmostEqual(sum(pos),1,places=8)
            self.assertAlmostEqual(sum(neg),1,places=8)
            self.assertGreater(model.posterior_p(pos),model.posterior_p(w))
            self.assertLess(model.posterior_p(neg),model.posterior_p(w))

    def test_last_period_dp_equals_immediate(self):
        for model in (x.NOMINAL,x.ROBUST):
            w=model.w0
            for b in (0,1,2):
                choices=[e for e in x.GRID if b or not x.is_probe(e)]
                self.assertAlmostEqual(model.value(1,w,b), min(model.immediate(w,e) for e in choices),places=9)

    def test_dynamic_bayes_global_over_allowed_grid(self):
        for model in (x.NOMINAL,x.ROBUST):
            for b in (0,1,2):
                for h in range(1,7):
                    w=model.w0
                    actions=[e for e in x.GRID if b or not x.is_probe(e)]
                    self.assertAlmostEqual(model.value(h,w,b),
                          min(model.action_value(h,w,b,e) for e in actions),places=10)
                    self.assertIn(model.decide(h,w,b,tuple(actions)),actions)

    def test_null_and_cost_components(self):
        for e in x.GRID:
            self.assertEqual(x.clinical_loss(0,e),0)
            self.assertAlmostEqual(x.clinical_loss(1,e)+x.clinical_loss(-1,e),x.EFFECT)
        env=x.Environment('test')
        u=[(1.,1.,.5)]*x.H
        vals,_=x.simulate_one(env,'safe_static_proxy',-1,u,0)
        self.assertAlmostEqual(vals['total'],sum(vals[k] for k in ('biological','acquisition','congestion','review')))
        self.assertAlmostEqual(vals['biological'],0)

    def test_grid_vs_continuous_not_confused(self):
        legal,reason=x.allowed_regular(.37,.43,2)
        self.assertEqual(reason,'NO_GRID_ACTION_CONTINUOUS_RESCUE')
        self.assertEqual(legal,(.4,))
        legal,reason=x.allowed_regular(.70,.30,2)
        self.assertEqual(reason,'NO_REGULAR_ACTION')
        self.assertFalse(legal)
        legal,reason=x.allowed_regular(.37,.43,0)
        self.assertEqual(reason,'NO_BUDGET_ACTION')
        self.assertFalse(legal)

    def test_reentry_requires_external_permission(self):
        positive=x.NOMINAL.signal(x.NOMINAL.w0,True)
        self.assertGreater(x.NOMINAL.posterior_p(positive),.8)
        allowed=(0.,.5,1.)
        yes=x.select_policy('kafka_gate',1,5,1,positive,0,1,allowed,True)
        no=x.select_policy('kafka_gate',1,5,1,positive,0,1,allowed,False)
        self.assertEqual(yes,1.)
        self.assertEqual(no,0.)
        stale=x.select_policy('kafka_gate',3,3,1,positive,0,1,allowed,True)
        self.assertEqual(stale,.5)

    def test_no_future_truth_enters_policy_interface(self):
        args=inspect.signature(x.select_policy).parameters
        self.assertFalse({'theta','truth','true_accuracy','future','latent'} & set(args))
        self.assertFalse({'theta','truth','true_accuracy'} & set(inspect.signature(x.BeliefModel.decide).parameters))

    def test_delayed_signals_age_by_source_cohort(self):
        env=x.Environment('delaytest',theta_mode='plus',delay=2)
        uniforms=[(0.,1.,0.)]+[(1.,1.,0.)]*5
        vals,trace=x.simulate_one(env,'kafka_gate',1,uniforms,0,audit_trace=True)
        self.assertEqual(trace[3]['last_evidence_cohort'],0)
        self.assertGreater(trace[3]['belief_before_action'],.8)
        self.assertLess(trace[3]['exposure'],.75) # 3-period old cohort cannot reenter
        self.assertEqual(trace[1]['observation_count'],0)
        self.assertEqual(trace[2]['observation_count'],0)
        self.assertEqual(trace[3]['observation_count'],1)

    def test_conflict_review_no_data_or_privilege(self):
        env=x.Environment('trial', rule='conflict')
        u=[(0.,1.,0.)]*x.H # would force acquisition if contingency incorrectly allowed it
        vals,trace=x.simulate_one(env,'kafka_gate',1,u,0,True)
        self.assertEqual(vals['contingencies'],3)
        self.assertEqual(vals['reviews_opened'],1)
        self.assertEqual(vals['review'],x.REVIEW_COST)
        self.assertEqual([trace[i]['authority_state'] for i in (2,3,4)],
                         ['PENDING_REVIEW','UNRESOLVED','UNRESOLVED'])
        for t in (2,3,4):
            self.assertEqual(trace[t]['acquired_probability'],0)
            self.assertEqual(trace[t]['exposure'],.1)
        self.assertEqual(trace[5]['authority_state'],'NORMAL')
        self.assertTrue(trace[5]['signed_external_release'])

    def test_no_budget_action_triggers_review(self):
        g=x.Gov()
        self.assertEqual(g.force_review(),x.REVIEW_COST)
        self.assertEqual(g.force_review(),0.)
        self.assertEqual(g.incidents,1)
        blocked,cost,why=g.check(0,1,False)
        self.assertTrue(blocked)
        self.assertEqual(cost,0.)
        blocked,cost,why=g.check(0,1,True)
        self.assertFalse(blocked)
        self.assertEqual(g.state,'NORMAL')

    def test_contingency_cannot_consume_probe_budget(self):
        env=x.Environment('conflict',rule='conflict')
        val,trace=x.simulate_one(env,'sentinel',1,[(0.,1.,0.)]*x.H,0,True)
        self.assertLessEqual(val['regular_probes'],2)
        self.assertEqual(val['contingencies'],3)
        self.assertEqual(val['authorization_violations'],0)

    def test_common_random_numbers_replicable(self):
        env=x.FAMILIES[0]
        u=x.exogenous(env,0,random.Random(314))
        self.assertEqual(u,x.exogenous(env,0,random.Random(314)))
        p1,_=x.simulate_one(env,'nominal_bayes',u[0],u[1],0)
        p2,_=x.simulate_one(env,'nominal_bayes',u[0],u[1],0)
        self.assertEqual(p1,p2)

    def test_monte_carlo_reconciles_theoretical_bayes(self):
        # Loose pre-declared tolerance due to finite 800 replicated episodes.
        with (ROOT/'results_policy_metrics.csv').open() as f:
            metrics=list(csv.DictReader(f))
        v=next(z for z in metrics if z['family']=='nominal_static' and z['policy']=='nominal_bayes')
        diff=abs(float(v['mean_loss'])-x.NOMINAL.value(x.H,x.NOMINAL.w0,x.PROBE_BUDGET))
        self.assertLess(diff,0.025)
        self.assertLess(diff,3*float(v['se_loss'])+0.001)

    def test_results_counts_and_integrity(self):
        with (ROOT/'results_policy_metrics.csv').open() as f:
            res=list(csv.DictReader(f))
        with (ROOT/'results_paired_differences.csv').open() as f:
            dif=list(csv.DictReader(f))
        self.assertEqual(len(res),18*9)
        self.assertEqual(len(dif),18*8)
        self.assertTrue(all(int(r['episodes'])==800 for r in res))
        self.assertTrue(all(0<=float(r['mean_regular_probes'])<=2 for r in res))
        self.assertTrue(all(math.isfinite(float(r['mean_loss'])) for r in res))
        lookup={(r['family'],r['policy']):float(r['mean_loss']) for r in res}
        for r in dif:
            expected=lookup[(r['family'],r['comparator'])]-lookup[(r['family'],'kafka_gate')]
            self.assertLess(abs(float(r['comparator_minus_kafka'])-expected),3e-8)

    def test_explicit_negative_results_not_redacted(self):
        with (ROOT/'results_policy_metrics.csv').open() as f:
            rows=list(csv.DictReader(f))
        d={(r['family'],r['policy']):float(r['mean_loss']) for r in rows}
        for fam in ('always_harm','null_effect','inverted_signal','weak_positivity'):
            self.assertGreater(d[(fam,'kafka_gate')],d[(fam,'safe_static_proxy')])
        self.assertGreater(d[('nominal_static','kafka_gate')],d[('nominal_static','nominal_bayes')])

    def test_metadata_disclaims_missing_inference(self):
        m=json.loads((ROOT/'metadata.json').read_text())
        self.assertFalse(m['independent_evaluator'])
        self.assertEqual(m['preregistration'],'NONE')
        self.assertIn('NOT ESTIMATED',m['frequency_coverage'])

if __name__=='__main__':
    unittest.main(verbosity=2)
