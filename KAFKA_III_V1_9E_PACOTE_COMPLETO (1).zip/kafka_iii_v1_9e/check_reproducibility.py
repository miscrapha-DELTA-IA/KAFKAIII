#!/usr/bin/env python3
"""Re-run final v1.9E experiment and compare output bytes; stdlib only."""
import hashlib, pathlib, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parent
FILES=('results_policy_metrics.csv','results_paired_differences.csv',
       'audit_example_paths.csv','metadata.json','family_summary.json')

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

before={f:sha(ROOT/f) for f in FILES}
proc=subprocess.run([sys.executable,str(ROOT/'experiment_v1_9e.py')],
                    cwd=ROOT,capture_output=True,text=True,check=True)
after={f:sha(ROOT/f) for f in FILES}
for name in FILES:
    assert before[name]==after[name], f'Non-reproducible output: {name}'
print(f'PASS: {len(FILES)} output files byte-identical after a complete rerun')
for name in FILES: print(f'{after[name]}  {name}')
