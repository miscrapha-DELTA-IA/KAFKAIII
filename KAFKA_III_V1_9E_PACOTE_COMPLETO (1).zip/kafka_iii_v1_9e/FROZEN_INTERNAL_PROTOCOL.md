# KAFKA III v1.9E — Matriz interna FIXADA para avaliação exploratória

Data da especificação: 2026-11-11. **Não constitui pré-registro público, registro temporal independente, nem validação externa.** A matriz e os critérios abaixo são fixados neste pacote antes da geração dos arquivos de resultado. A implementação e a geração de dados pertencem à mesma equipe/processo: não existe avaliador independente.

## Estimando
Perda acumulada por trajetória sintética em 6 períodos: `Σ_t [0.10*((1-e_t) se θ_t=+1; e_t se θ_t=-1; 0 se θ_t=0) + 0.001*q_true(e_t) + κ*e_t²] + 0.02*(novos incidentes de revisão)`. A expressão `κ*e²` é um custo de congestionamento **somente** na família de clusters sintéticos; não infere interferência causal real. Menor é melhor. Os termos são componentes distintos de custo e não incorporam novamente perdas ao calcular métricas auxiliares. Custos e margens **não são calibrados clinicamente**. A exposição de contingência é executada como suposição sintética, **não** como autorização clínica.

## Informação, ação e recursos
Todos os métodos começam com `Pr(θ=+1)=0.42`, assumem efeito em magnitude 0.10, conhecem horizonte 6 e enfrentam a mesma malha regular `{0,.25,.5,.75,1}` e `q_assumed(e)=0.02+4*(0.82-0.02)e(1-e)`. Apenas 2 períodos com `0<e<1` são permitidos por trajetória para **ações regulares**; custo real de aquisição `0.001*q_true(e)` contabilizado para todos. Sinais de dois braços (se adquiridos e não faltantes) são observados **após** o período de decisão, podendo sofrer atraso; atualização é apenas por sinais recebidos, nunca pelo estado verdadeiro. Sinais ausentes não atualizam crenças. A assinatura externa é sinal de autorização, não evidência. Todos os comparadores enfrentam idênticas restrições de ação, observação, atraso, assinatura e revisão, mas suas exposições distintas geram dados distintos (observabilidade endógena).

## Políticas congeladas
`kafka_gate`: começa suspensa, pode usar sonda e=.5 nos períodos 0 e 3 (sujeito a limite de 2); habilita e=1 por no máximo 2 períodos após sinal recebido há <=2 períodos, crença nominal >=.80, e permissão externa exógena; sem esses critérios usa e=0, salvo sonda agendada. Não é a arquitetura histórica completa do projeto. `nominal_bayes`: DP Bayes ótimo no modelo estático nominal com acurácia .85, ações/limite de 2 sondas. `robust_bayes_mix`: DP Bayes ótimo para mistura pré-fixada de acurácias .55 e .85 com pesos 1/2; é Bayes com incerteza, **não** garantia minimax geral. `minimax_one_step`: minimiza pior perda imediata para p∈[p_hat-.35,p_hat+.35] truncado a [0,1], inclui custo de aquisição e limite. `greedy`: minimiza perda imediata posterior nominal mais custo. `safe_static_proxy`: ação 0 (baseline conservadora fixa, **não** equivalência comprovada à implementação de safe policy learning da v1.8A). `historical_on`: ação 1 fixa, representa um alerta histórico positivo ignorando evidência nova. `sentinel`: e=.5 nos períodos 0,3; caso contrário e=0. `fixed_probe`: e=.5 nos períodos 0,1; caso contrário e=0. Políticas fixas projetam sua escolha no conjunto regular viável presente; caso indisponível, seguem contingência.

## Famílias de geradores sintéticos (mesma lista e parâmetros em `experiment_v1_9e.py`)
1. nominal_static (θ latente com p=.42, acurácia=.85)
2. always_benefit (θ=+1)
3. always_harm (θ=-1)
4. null_effect (θ=0)
5. harm_to_benefit (θ=-1 nos t<3, +1 a seguir)
6. benefit_to_harm (θ=+1 nos t<3, -1 a seguir)
7. reverse_after_reentry_window (θ=-1 nos t<2, +1 nos 2<=t<4, -1 depois; reversão temporal, reentrada não garantida)
8. heterogeneity_two_strata (θ=+1 nos episódios de estrato A e θ=-1 no B, 50/50)
9. inverted_signal (a verdadeira=.25)
10. weak_signal (a=.55)
11. prior_shift (θ sorteado com p=.85)
12. informative_missingness (ausência condicionada θ: .05 no + e .70 no -)
13. delayed_outcomes (atraso de 2 períodos adicionais)
14. weak_positivity (q0=.001, qmax=.06)
15. cluster_congestion_proxy (κ=.04; componente de recurso compartilhado sintético, não inferência cluster-randomized)
16. governance_conflict (limites incompatíveis t=2,3; viáveis t=4,5, mas assinatura externa somente t=5)
17. grid_only_gap (em t=1, limites regulares [.37,.43], sem ponto na malha; ação contínua regular no ponto médio se houver orçamento)
18. drifting_accuracy (a verdadeira=.9 nos t<3, .3 depois)

## Estatística, desfechos e falsificadores
`N=800` trajetórias por família, sementes `20261111 + 1009*idx`, fluxos comuns de uniformes por período dentro de cada família para comparação pareada entre políticas. Relatar perda média e erro padrão, diferenças pareadas Kafka–comparadores e IC normal 95% **descritivos não ajustados**, proporção de suspensão errada, de reentrada errada, de sondas, contingência, decisões inconclusivas, orçamento consumido, número de evidências recebidas e violações de autorização. Regra de falso positivo/negativo depende de θ latente e só é calculada pelo avaliador. A cobertura estatística frequencista não será avaliada: não existe intervalo inferencial construído. Sem dados reais ou revisão independente, nenhuma margem normativa de ganho/dano e nenhum gate confirmatório podem ser aprovados.

## Critérios de refutação
Registrar (i) qualquer família com perda Kafka acima de `safe_static_proxy` ou de planejadores fortes; (ii) falhas sob sinal invertido, MNAR, reversão temporal, atrasos ou falta de positividade; (iii) ausência de incremento além de métodos existentes; (iv) bloqueio de reentrada sem evidência/assinatura; (v) NO_GRID_ACTION separado de NO_REGULAR_ACTION; (vi) qualquer violação de limite de duas sondas, autorização, custos ou posterior sem sinal. Comparação com `safe_static_proxy` NÃO satisfaz gate de equivalência a safe learning histórico. Não alegar superioridade geral nem eficácia clínica, mesmo se médias parecerem melhores.
