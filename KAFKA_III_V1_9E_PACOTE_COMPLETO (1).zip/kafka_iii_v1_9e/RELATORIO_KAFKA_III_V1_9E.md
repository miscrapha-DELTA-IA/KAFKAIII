# KAFKA III — Relatório técnico exploratório v1.9E

**Data:** 11 de novembro de 2026  
**Título científico do projeto:** *When Should a Biomedical Prediction Lose Its Authority to Guide Care?*  
**Classificação:** investigação computacional interna **exploratória**, reproduzível; **sem eficácia clínica, sem pré-registro público, sem avaliador independente.**

## 1. Proveniência e continuidade

O protocolo candidato `PROTOCOLO_CANDIDATO_V1_9E.md` da v1.9D foi recuperado e usado como lista de requisitos. A v1.9D demonstrou que o planejador Bayes podia superar a regra míope no modelo correto, mas que a vantagem podia inverter sob erro de acurácia. A v1.9E não repete nem revalida os 192 casos relatados pela v1.9C nem converte resultados exploratórios anteriores em confirmação.

**SHA-256 do pacote v1.9D de entrada:** `5fdfd4e2826588f3c98b84a05d2fd9f6c2378b3607a2adcbf055a049d90a95df`.

A matriz interna (`FROZEN_INTERNAL_PROTOCOL.md`) foi especificada antes da primeira execução. O mesmo desenvolvedor também implementou, observou os resultados preliminares e corrigiu o código antes da saída final. Todas as alterações estão em `CHANGELOG_AND_LIMITATIONS.md`. Por isso, essa especificação **não é um pré-registro cego, independente ou confirmatório**.

## 2. Estimando, informação e admissibilidade

Em cada período `t`, o efeito latente sintético pertence a `θ_t∈{-1,0,+1}`, e a ação é a fração de exposição `e_t∈[0,1]`. A perda biológica descritiva é `0.10*(1-e_t)` para benefício verdadeiro, `0.10*e_t` para dano verdadeiro e `0` para efeito nulo. Somam-se custo de aquisição `0.001*q_true(e_t)`, penalidade de congestão `κ*e_t²` apenas na família de clusters e custo único de `0.02` por incidente de revisão. Não há dupla contagem ao reportar métricas auxiliares de decisões erradas.

O canal comparativo assume `q(e)=q0+4*(qmax-q0)*e*(1-e)`, com maior chance de sinal quando há dois grupos representados. O modelo dos planejadores supõe `q0=.02`, `qmax=.82`, precisão `.85` (ou mistura `.55/.85`) e prior `Pr(θ=+)=.42`. O avaliador pode alterar θ, precisão, observabilidade, atraso e missingness; **nenhum controlador recebe θ verdadeiro ou a precisão verdadeira**. Sinais pendentes chegam após a decisão e mantêm o **timestamp da coorte de origem**, não o da entrega. Ausência de sinal não atualiza a crença.

Todas as políticas recebem o mesmo gerador de dados potenciais, custos, calendário e orçamento de **no máximo dois períodos de sondagem regular**. O conjunto nominal de ações regulares é `{0,.25,.5,.75,1}`; intervalos contínuos estreitos podem exigir o ponto médio fora da malha. Dados observados diferem legitimamente porque a exposição escolhida altera a chance de aquisição. A autorização de reentrada simulada é **um requisito adicional autoimposto pela regra KAFKA candidata**, não uma proibição geral que todos os outros planejadores devem cumprir; as restrições externas regulares de exposição e revisão são compartilhadas.

Quando os limites são incompatíveis, nenhuma ação regular é declarada admissível. Um protocolo de **contingência puramente sintético** escolhe `e=.10`, cobra revisão uma vez e impede aquisição de evidência durante esse ato (`q_true=0`); a liberação exige dados de limites viáveis e assinatura exógena. A ação de contingência não constitui autorização médica ou regulatória.

## 3. Métodos comparados

- **`kafka_gate`:** regra candidata simplificada com sondas programadas, limiar de crença `.80`, idade da coorte ≤2 períodos e permissão de reentrada exógena. **Não** é a implementação integral do KAFKA III.
- **`nominal_bayes`:** programação dinâmica Bayes exatamente ótima **dentro do modelo estático assumido**, com a mesma grade de ações e orçamento.
- **`robust_bayes_mix`:** programação dinâmica de uma mistura Bayes pré-definida de precisões `.55` e `.85`; não é um ótimo minimax geral.
- **`minimax_one_step`:** regra de proteção de pior risco **de um período** com envelope de prior ±.35; não é um POMDP robusto ótimo.
- **`greedy`:** otimização míope de perda imediata; **`safe_static_proxy`:** ação estática conservadora sem exposição; **`historical_on`:** exposição histórica fixa; **`sentinel` e `fixed_probe`:** sondagens fixas em calendários distintos.

O código do safe policy learning histórico (v1.8A) não foi reconstruído neste ensaio. Portanto, a equivalência de `safe_static_proxy` com o método histórico exigida pelo protocolo candidato **não foi demonstrada**.

## 4. Desenho experimental e reprodutibilidade

- **18 famílias de geradores:** nominal; benefício, dano, nulo; três reversões; estratos; sinal invertido/fraco; prior deslocado; censura informativa; atraso; baixa positividade; congestão de cluster como proxy; conflito; lacuna de grade; precisão variável.
- **9 políticas × 800 trajetórias/família × 18 famílias = 129.600 trajetórias** de seis decisões sintéticas cada.
- Sementes inteiras por família: `20261111+1009*i`, `i=0,…,17`. Fluxos de uniformes exógenos compartilhados entre políticas por trajetória; **não** sementes finais retidas por avaliador externo.
- Todos os parâmetros, cenários e funções constam em `experiment_v1_9e.py` e `metadata.json`.
- Contrastes pareados e intervalos normais 95% Monte Carlo **descritivos, não ajustados para multiplicidade**. Não existem intervalos de confiança causais ou sequências de confiança do efeito de tratamento.

## 5. Resultados completos — perda acumulada média

Quanto menor o valor, menor a perda **do gerador sintético**; valores não são benefícios clínicos calibrados.

| Família | KAFKA | Bayes nominal | Bayes mistura | Estática segura (proxy) |
|---|---:|---:|---:|---:|
| Modelo nominal estático | 0,1611 | 0,1406 | 0,1408 | 0,2439 |
| Benefício persistente | 0,2500 | 0,1438 | 0,1843 | 0,6001 |
| Dano persistente | 0,0963 | 0,1216 | 0,0978 | 0,0001 |
| Efeito nulo | 0,0016 | 0,0014 | 0,0015 | 0,0001 |
| Dano → benefício | 0,3226 | 0,3404 | 0,3509 | 0,3001 |
| Benefício → dano | 0,1855 | 0,3346 | 0,3429 | 0,3001 |
| Reversões sucessivas | 0,2781 | 0,2742 | 0,2713 | 0,2001 |
| Dois estratos distintos | 0,1669 | 0,1278 | 0,1342 | 0,3001 |
| Sinal invertido | 0,3784 | 0,4219 | 0,4023 | 0,2431 |
| Sinal fraco | 0,2730 | 0,2746 | 0,2661 | 0,2694 |
| Prior verdadeiro deslocado | 0,2182 | 0,1391 | 0,1719 | 0,5056 |
| Censura informativa (MNAR) | 0,1756 | 0,1401 | 0,1566 | 0,2491 |
| Atraso adicional | 0,2573 | 0,1933 | 0,1933 | 0,2589 |
| Baixa positividade | 0,2634 | 0,2586 | 0,2591 | 0,2588 |
| Congestão de cluster (proxy) | 0,2299 | 0,2278 | 0,2169 | 0,2574 |
| Conflito de governança | 0,2622 | 0,2390 | 0,2415 | 0,2721 |
| Lacuna da malha | 0,2099 | 0,1605 | 0,1605 | 0,2469 |
| Precisão da evidência variável | 0,1953 | 0,1112 | 0,1152 | 0,2589 |

Tabela de todas as nove políticas, componentes de perda, métricas operacionais e respectivos erros-padrão: `results_policy_metrics.csv`. Todas as diferenças pareadas disponíveis em `results_paired_differences.csv`.

### 5.1 Contrastes centrais (diferença pareada = perda do comparador − perda KAFKA)

Sinal negativo significa que **KAFKA teve maior perda**. Os intervalos são apenas de variação Monte Carlo e não controlam seleção ou multiplicidade.

| Família | Comparador | Diferença comparador − KAFKA | IC Monte Carlo 95% |
|---|---|---:|---|
| Modelo nominal estático | `nominal_bayes` | -0,0205 | [-0,0299; -0,0112] |
| Modelo nominal estático | `safe_static_proxy` | 0,0828 | [0,0648; 0,1008] |
| Benefício persistente | `nominal_bayes` | -0,1062 | [-0,1143; -0,0980] |
| Dano persistente | `safe_static_proxy` | -0,0962 | [-0,1027; -0,0897] |
| Efeito nulo | `safe_static_proxy` | -0,0014 | [-0,0015; -0,0014] |
| Sinal invertido | `safe_static_proxy` | -0,1353 | [-0,1534; -0,1171] |
| Reversões sucessivas | `safe_static_proxy` | -0,0780 | [-0,0826; -0,0734] |
| Atraso adicional | `nominal_bayes` | -0,0640 | [-0,0751; -0,0528] |
| Baixa positividade | `safe_static_proxy` | -0,0046 | [-0,0130; 0,0037] |
| Benefício → dano | `nominal_bayes` | 0,1492 | [0,1403; 0,1580] |

### 5.2 Falhas que devem permanecer no manuscrito

- **Dano persistente:** perda KAFKA `0,0963` contra `0,0001` do baseline estático. A aquisição e decisões erradas podem criar dano desnecessário.
- **Sinal invertido:** perda KAFKA `0,3784` contra `0,2431` estático. Evidência enganosa pode reforçar autoridade sem justificação.
- **Reversões sucessivas:** perda KAFKA `0,2781` contra `0,2001` estático. A melhor decisão histórica não transporta automaticamente seu efeito para o futuro.
- **Modelo nominal:** perda KAFKA `0,1611` contra `0,1406` do planejador Bayes. Não há vantagem incremental sobre o benchmark Bayes corretamente especificado.
- **Atraso:** a idade de uma evidência é medida desde a coorte de origem; um sinal entregue tarde não pode artificialmente renovar seu prazo de validade.
- **Baixa positividade/sinal fraco:** diferenças modestas podem cruzar zero nos intervalos Monte Carlo; não são demonstrações de superioridade nem equivalência.
- **Efeito nulo:** sondagens com custo podem tornar política dinâmica pior que abstenção sem acrescentar benefício biológico.

Das 18 famílias, KAFKA apresentou maior média de perda que `safe_static_proxy` em **7** e que `nominal_bayes` em **13**. Essa contagem é descritiva e depende de seleção de famílias/modelos; **não** é uma probabilidade de falha em ambientes reais.

### 5.3 Métricas de decisão e auditoria

- Dano persistente: exposição alta em estado prejudicial, média **0,3088 períodos/episódio**; sinal invertido: **1,3062 períodos/episódio**. Métrica calculada somente pelo avaliador, não observável diretamente pela política.
- Baixa positividade: média **0,1275 sinais efetivamente recebidos** em seis decisões e **5,6025 períodos inconclusivos** por trajetória KAFKA.
- Conflito de governança: **três períodos de contingência**, uma revisão por episódio e custo de revisão `0.02` em todas as trajetórias daquela família; o estado permanece não resolvido até atualização externa assinada. O sinal não é criado pelo mecanismo de revisão.
- Lacuna da malha: o intervalo contínuo `[.37,.43]` é admissível, mas não contém ponto na malha; a ação regular `.40` pode ser usada quando resta orçamento. `NO_GRID_ACTION` não é confundido com `NO_REGULAR_ACTION`.
- Nenhuma trajetória final excedeu duas sondagens **regulares**, e a auditoria da regra KAFKA não identificou reentrada acima do limiar sem credencial simulada e evidência recente. Isso garante apenas consistência do código nas hipóteses testadas, não segurança clínica.
- `false_suspends`, `false_reentries`, decisões inconclusivas, evidências tardias, custo de aquisição, custos de revisão e contingência estão disponíveis por política e família no CSV. As contagens de exposição alta sob dano não pressupõem que tenha existido uma reentrada após uma suspensão formal.

## 6. Proposição analítica de limite informacional (clássica)

**Proposição condicional.** Suponha um período futuro com efeito de magnitude `d>0`, sem observação capaz de distinguir dois mundos igualmente compatíveis com o mesmo histórico: no mundo A, expor beneficia; no mundo B, expor prejudica. A perda de uma ação aleatória/contínua com exposição média `e∈[0,1]` é `d(1-e)` no primeiro mundo e `de` no segundo. Logo `max{d(1-e), de}≥d/2`, com mínimo em `e=1/2`. Restringir ações não pode melhorar essa cota.

**Interpretação:** na ausência de qualquer hipótese de transporte temporal ou dado prospectivo antes da decisão, nenhum controlador pode garantir perda menor que `d/2` em ambos os mundos nesse problema simples. Isso é um argumento minimax elementar, **não** um teorema novo KAFKA ou prova geral de impossibilidade clínica. Revisões administrativas sem novos dados não eliminam indistinguibilidade estatística.

## 7. Gates metodológicos — decisão

| Gate | Estado | Razão |
|---|---|---|
| Fidelidade de ações/custos/informação do toy | Parcial | Mesmo mecanismo de observação e orçamento; dados diferem por exposição, mas equivalência ao safe learning histórico não demonstrada |
| Segurança de execução do toy | Aprovado nos testes internos | Nenhuma ação regular é forçada em conjunto vazio; contingência separada; sem dados gratuitos na contingência; revisão não concede sinal |
| Robustez | **Não aprovado** | Dano, inversão de sinal e reversões mantêm resultados adversos à regra candidata |
| Cobertura estatística | Não avaliado | Nenhum intervalo frequentista ou controle simultâneo de múltiplas consultas foi construído |
| Cluster/interferência | Não avaliado de forma identificada | κ de congestão é proxy sem desenho hospitalar aleatorizado |
| Originalidade incremental | **Não demonstrada** | Mecanismo KAFKA simplificado não melhora uniformemente Bayes e baseline estático |
| Confirmação clínica | **Bloqueado** | Sem custos legitimados, registro público, avaliador externo, estimando causal ou consentimento |

## 8. Testes, trilha e reconstrução

- `test_v1_9e.py` contém **18 testes unitários** independentes da rotina principal, cobrindo recursão de Bellman, normalização Bayes, fronteiras de positividade, sem vazamento de verdade, idade da coorte, veto de assinatura, orçamento, contingência, estados de revisão, identidade de custos, matrizes e preservação de resultados negativos.
- `check_reproducibility.py` reexecuta todas as 129.600 trajetórias e verifica a igualdade **byte a byte** de cinco arquivos principais. Ver `reproducibility_log.txt`.
- `audit_example_paths.csv` possui trajetórias exemplares com crença antes da decisão, estado, sinal, exposição, timestamp de coorte e condição de assinatura. A coluna `theta_evaluator_only` pertence exclusivamente à auditoria, nunca ao planejador.
- `metadata.json`, `run_log.json`, `tests_log.txt`, `manifest_sha256.txt` e `CHANGELOG_AND_LIMITATIONS.md` documentam ambiente, cenários, parâmetros, testes e correções.

Executar na pasta do pacote, sem internet nem dependências externas:

```bash
python experiment_v1_9e.py > run_log.json
python test_v1_9e.py > tests_log.txt 2>&1
python check_reproducibility.py > reproducibility_log.txt
python generate_report.py
```

## 9. Implicações editoriais e candidata v1.9F

A v1.9E fortalece a parte negativa da tese (limites de autoridade, observabilidade e transporte temporal), mas **não** demonstra superioridade incremental da arquitetura KAFKA. Não existe base para artigo de eficácia, implantação ou teste com pacientes.

A v1.9F, **somente após revisão externa**, deveria: (i) recuperar e demonstrar equivalência exata ao safe policy learning histórico; (ii) separar ação regular, contingência e credenciais universalmente exigidas para todos os métodos; (iii) contratar avaliador cego com sementes finais e margens clínicas pré-especificadas; (iv) usar geradores com atraso, drift, MNAR e desenlaces com identificação adequada; (v) modelar hospitais por randomização e desfechos sob interferência; (vi) construir inferência com cobertura simultânea auditada; (vii) comparar planejador Bayes/POMDP robusto e minimax multietapas genuínos; e (viii) publicar falhas e análises de sensibilidade integralmente.

**Decisão final v1.9E:** pacote de falsificação exploratória concluído; **gate confirmatório não aprovado**.

