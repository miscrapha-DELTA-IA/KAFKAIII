# KAFKA III v1.9E — Proveniência e alterações durante a auditoria interna

Esta execução **não** foi cega, independente ou previamente registrada. O arquivo `FROZEN_INTERNAL_PROTOCOL.md` foi escrito como matriz candidata antes da primeira geração dos resultados. Durante ensaios iniciais internos (antes do pacote final) foram feitas correções no código, reexecutando **todas** as famílias e políticas após cada correção. Não confundir a expressão "fixado internamente" com pré-registro público ou seleção imune a pós-ajustes.

## Correções documentadas

1. **Contingência sem aquisição de evidência:** uma versão inicial permitia adquirir novos sinais diagnósticos durante a exposição de contingência. Isso contornava o limite de sondagem e poderia criar privilégio informacional não autorizado. A versão final impõe `q_true=0` na contingência; ainda contabiliza perda biológica e custo de incidente.
2. **Idade temporal da evidência:** no protótipo inicial a idade era calculada desde a entrega, mesmo que a coorte fosse antiga. Agora é medida desde a **coorte de origem** (`last_evidence_cohort`), impedindo que um desfecho atrasado seja considerado contemporâneo.
3. **Ausência de ação pelo orçamento:** caso nenhuma ação regular caiba no orçamento, um incidente de revisão é aberto e a contingência permanece separada; a revisão exige permissão externa assinada para liberação.
4. **Permissão de reentrada exógena:** removida uma condição tautológica de assinatura e substituída por `reentry_authorized(env,t)`, uma agenda independente do estado verdadeiro e do sinal, cujo token hipotético é acessível como regra exógena. Não representa assinatura institucional real.
5. **Auditoria de autorização efetiva:** `authorization_violations` é agora computado da crença disponível, idade da coorte e permissão, em vez de uma variável inicializada em zero.

A matriz de 18 famílias, os 9 comparadores, `N=800`, horizonte de 6 períodos e sementes não foram alterados nas correções acima. Todos os outputs publicados foram recomputados da versão final de código.

## Aditamento sem alteração da matriz

A regra de custos definida no protocolo deve ser lida com `q_true(e)=0` quando a ação executada for **contingência**, pois ela não possui protocolo de aquisição válido. Nas ações regulares continua a função específica de cada ambiente. A data de evidência para a autorização é sempre a data da coorte amostrada, nunca a data de entrega.

## Limitações bloqueantes

- O baseline `safe_static_proxy` não foi demonstrado algébrica e computacionalmente equivalente ao safe policy learning da v1.8A. Nenhuma conclusão de incremento sobre aquele algoritmo histórico é autorizada.
- O `kafka_gate` é heurística sintética simplificada, não o software integral da arquitetura KAFKA III.
- O planejador exato Bayes é ótimo apenas no seu modelo nominal estático e sob sua malha/limite; não é benchmark universal ou ótimo sob todas as 18 famílias.
- A mistura robusta é uma hipótese Bayes discreta pré-fixada; não é prova minimax.
- O custo de congestão por cluster é um **proxy** de recurso agregado; não constitui randomização por hospitais ou estimativa sob interferência.
- Os sinais são evidência comparativa abstrata. Não existe identificação causal de dados reais, estimando hospitalar validado, cobertura simultânea, MNAR-identificação ou auditor externo.
- As despesas de revisão, margem de segurança, duração e exposições contingenciais são unidades sintéticas; podem ser eticamente inadmissíveis na prática.
- A amostra Monte Carlo (`N=800`) e ICs descritivos 95% não têm controle de multiplicidade nem justificam divulgação de eficácia.
