# KAFKA III — Protocolo candidato para v1.9F (não pré-registrado)

**Objetivo:** verificar, por auditoria verdadeiramente independente e benchmarks metodológicos completos, se a governança de autoridade oferece incremento em relação a alternativas existentes após ter falhado em múltiplas famílias da v1.9E.

## Restrições antes de novo experimento

1. **Recuperar a implementação original da regra de safe policy learning da v1.8A** e provar equivalência do baseline estático, para eliminar o proxy fraco da v1.9E.
2. **Congelar uma autorização universal e idêntica entre políticas**, distinguindo permissão regulatória externa de um gate de política autoimposto. Sem uniformidade de direitos, contrastes de governança não interpretáveis.
3. **Contratar avaliador externo cego**, com protocolo público anterior a sementes/ambientes de teste, impedindo mudanças motivadas por resultados finais.
4. **Definir perdas com equipe clínica e de ética:** exposição nociva, suspensão de benefício, custo de amostragem, impacto de atraso, carga assistencial, custo jurídico de contingência, autonomia e repercussão por hospital. Esses pesos não podem ser imputados do modelo ilustrativo.
5. **Comparar planejadores fortes:** Bayes/POMDP com atraso e observação dependente da ação, Bayes de incerteza de parâmetros, robusto/minimax multietapas, safe learning estático verdadeiro, sentinela, orçamento fixo, regra histórica e KAFKA completo.
6. **Identificação e desfechos:** amostragem em dois braços, atrasos individuais e missingness MNAR; construir estimando causal, positividade e análise de sensibilidade com hipóteses explícitas. Informação administrativa jamais cria efeito causal identificado.
7. **Unidades sob interferência:** randomização por hospitais/grupos, estimando de política hospitalar e capacidade compartilhada. Não transportar o proxy `κe²` como resultado de interferência.
8. **Alfa global e cobertura:** auditar intervalos simultâneos para estimandos históricos com consultas adaptativas e janelas, sem transportá-los automaticamente ao futuro.
9. **Reportar falsificadores sem supressão:** dano persistente, sinal invertido, mudança de sinal após reentrada, benefício persistente, ausência de informação, custo de aquisição, drift de acurácia e indisponibilidade de ação admissível.
10. **Critério de não avanço:** se equivalência de baseline, validade inferencial e comparabilidade de permissões não forem estabelecidas, não executar experimento confirmatório nem reivindicar eficácia/originalidade.

## Hipóteses sujeitas a teste

- Uma regra de autoridade **pode** reduzir dano excessivo em algumas famílias de mudanças, mas pode piorar perda acumulada sob danos persistentes, sinais invertidos e atraso.
- A utilidade da aquisição de informação depende de custo, atraso, validade temporal e positividade, não apenas de exatidão nominal do POMDP.
- Uma revisão sem novos dados não melhora a identificação causal, mesmo que mude permissões administrativas.

Nenhuma hipótese está confirmada pela v1.9E. Este arquivo é só um **candidato** metodológico; o projeto ainda não tem protocolo clínico legitimado.
