# KAFKA III — pacote técnico v1.9E

**Natureza:** experimento sintético de falsificação interno; **não** é validação clínica, científica externa, pré-registro público, nem resultado causal aplicado a pacientes.

## Arquivos principais

- `RELATORIO_KAFKA_III_V1_9E.md`: relatório completo, 18 famílias, tabela com 9 políticas, contrafactuais, resultados adversos, auditoria e decisão de gates.
- `experiment_v1_9e.py`: gerador sintético de episódios, 9 políticas, dois planejadores Bayes DP, condições adversas, orçamento, revisão e métricas.
- `test_v1_9e.py`: 18 testes unitários (inclui testes de falha e direitos de acesso).
- `check_reproducibility.py`: reexecução completa e verificação de 5 hashes dos resultados.
- `generate_report.py`: regenera relatório a partir dos arquivos de resultados.
- `results_policy_metrics.csv`: 162 linhas, família x política, perdas e componentes, medidas de decisões e erros-padrão.
- `results_paired_differences.csv`: 144 diferenças pareadas KAFKA vs comparadores, com intervalos Monte Carlo descritivos.
- `audit_example_paths.csv`: trajetórias exemplares, sem dados de pessoas reais.
- `run_log.json`, `family_summary.json`, `metadata.json`: dados de execução e parâmetros.
- `tests_log.txt`, `reproducibility_log.txt`, `manifest_sha256.txt`: registro de verificações e hashes.
- `PROTOCOLO_ORIGEM_V1_9D.md`: cópia do protocolo candidato recuperado do pacote v1.9D.
- `FROZEN_INTERNAL_PROTOCOL.md`: matriz interna candidata da etapa v1.9E, **não** um pré-registro público.
- `CHANGELOG_AND_LIMITATIONS.md`: alterações feitas durante auditoria interna, sem alegação de cegamento.
- `PROTOCOLO_CANDIDATO_V1_9F.md`: proposta de próximos requisitos, sem status de protocolo aprovado.

## Reproduzir (Python 3.10 ou superior, biblioteca padrão)

A partir da pasta descompactada:

```bash
python experiment_v1_9e.py > run_log.json
python test_v1_9e.py > tests_log.txt 2>&1
python check_reproducibility.py > reproducibility_log.txt
python generate_report.py
```

Os outputs gerados devem ser os mesmos para o mesmo código/intérprete; a comparação dos cinco arquivos principais é feita **byte a byte**. O hash dos arquivos distribuídos está no manifesto. O relatório pode ser regenerado depois da execução dos resultados.

## Advertências críticas

O controlador chamado `kafka_gate` não representa toda a arquitetura KAFKA; o `safe_static_proxy` não substitui a implementação de safe policy learning da v1.8A. O cluster é apenas uma função ilustrativa de congestionamento. Não há calibração de perdas clínicas, controle de multiplicidade, intervalo de cobertura causal, autorização institucional, auditor independente nem desenho hospitalar randomizado. O relatório registra explicitamente os cenários em que a regra candidata **perde** para alternativas.
