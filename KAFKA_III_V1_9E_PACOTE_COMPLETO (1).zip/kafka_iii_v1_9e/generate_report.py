#!/usr/bin/env python3
"""Deterministic report generator from final v1.9E CSV outputs."""
from pathlib import Path
import csv, json, hashlib
ROOT=Path(__file__).resolve().parent

def rows(name):
    with (ROOT/name).open(encoding='utf8',newline='') as f:return list(csv.DictReader(f))

m=rows('results_policy_metrics.csv')
d=rows('results_paired_differences.csv')
mi={(x['family'],x['policy']):x for x in m}
di={(x['family'],x['comparator']):x for x in d}
order=[x['family'] for x in m if x['policy']=='kafka_gate']
def n(f,p):return float(mi[(f,p)]['mean_loss'])
def format_n(x):return f'{x:.4f}'.replace('.',',')
def dci(f,p):
    z=di[(f,p)]
    return f"[{format_n(float(z['ci95_low']))}; {format_n(float(z['ci95_high']))}]"
def gain(f,p):return float(di[(f,p)]['comparator_minus_kafka'])
old=ROOT.parent/'KAFKA_III_V1_9D_PACOTE_COMPLETO.zip'
oldhash=hashlib.sha256(old.read_bytes()).hexdigest() if old.exists() else 'não disponível'
fail_static=[f for f in order if n(f,'kafka_gate')>n(f,'safe_static_proxy')+1e-6]
fail_nom=[f for f in order if n(f,'kafka_gate')>n(f,'nominal_bayes')+1e-6]
label={
 'nominal_static':'Modelo nominal estático',
 'always_benefit':'Benefício persistente',
 'always_harm':'Dano persistente',
 'null_effect':'Efeito nulo',
 'harm_to_benefit':'Dano → benefício',
 'benefit_to_harm':'Benefício → dano',
 'reverse_after_reentry_window':'Reversões sucessivas',
 'heterogeneity_two_strata':'Dois estratos distintos',
 'inverted_signal':'Sinal invertido',
 'weak_signal':'Sinal fraco',
 'prior_shift':'Prior verdadeiro deslocado',
 'informative_missingness':'Censura informativa (MNAR)',
 'delayed_outcomes':'Atraso adicional',
 'weak_positivity':'Baixa positividade',
 'cluster_congestion_proxy':'Congestão de cluster (proxy)',
 'governance_conflict':'Conflito de governança',
 'grid_only_gap':'Lacuna da malha',
 'drifting_accuracy':'Precisão da evidência variável',
}
lines=[]
lines += [
 '# KAFKA III — Relatório técnico exploratório v1.9E',
 '',
 '**Data:** 11 de novembro de 2026  ',
 '**Título científico do projeto:** *When Should a Biomedical Prediction Lose Its Authority to Guide Care?*  ',
 '**Classificação:** investigação computacional interna **exploratória**, reproduzível; **sem eficácia clínica, sem pré-registro público, sem avaliador independente.**',
 '',
 '## 1. Proveniência e continuidade',
 '',
 'O protocolo candidato `PROTOCOLO_CANDIDATO_V1_9E.md` da v1.9D foi recuperado e usado como lista de requisitos. A v1.9D demonstrou que o planejador Bayes podia superar a regra míope no modelo correto, mas que a vantagem podia inverter sob erro de acurácia. A v1.9E não repete nem revalida os 192 casos relatados pela v1.9C nem converte resultados exploratórios anteriores em confirmação.',
 '',
 f'**SHA-256 do pacote v1.9D de entrada:** `{oldhash}`.',
 '',
 'A matriz interna (`FROZEN_INTERNAL_PROTOCOL.md`) foi especificada antes da primeira execução. O mesmo desenvolvedor também implementou, observou os resultados preliminares e corrigiu o código antes da saída final. Todas as alterações estão em `CHANGELOG_AND_LIMITATIONS.md`. Por isso, essa especificação **não é um pré-registro cego, independente ou confirmatório**.',
 '',
 '## 2. Estimando, informação e admissibilidade',
 '',
 'Em cada período `t`, o efeito latente sintético pertence a `θ_t∈{-1,0,+1}`, e a ação é a fração de exposição `e_t∈[0,1]`. A perda biológica descritiva é `0.10*(1-e_t)` para benefício verdadeiro, `0.10*e_t` para dano verdadeiro e `0` para efeito nulo. Somam-se custo de aquisição `0.001*q_true(e_t)`, penalidade de congestão `κ*e_t²` apenas na família de clusters e custo único de `0.02` por incidente de revisão. Não há dupla contagem ao reportar métricas auxiliares de decisões erradas.',
 '',
 'O canal comparativo assume `q(e)=q0+4*(qmax-q0)*e*(1-e)`, com maior chance de sinal quando há dois grupos representados. O modelo dos planejadores supõe `q0=.02`, `qmax=.82`, precisão `.85` (ou mistura `.55/.85`) e prior `Pr(θ=+)=.42`. O avaliador pode alterar θ, precisão, observabilidade, atraso e missingness; **nenhum controlador recebe θ verdadeiro ou a precisão verdadeira**. Sinais pendentes chegam após a decisão e mantêm o **timestamp da coorte de origem**, não o da entrega. Ausência de sinal não atualiza a crença.',
 '',
 'Todas as políticas recebem o mesmo gerador de dados potenciais, custos, calendário e orçamento de **no máximo dois períodos de sondagem regular**. O conjunto nominal de ações regulares é `{0,.25,.5,.75,1}`; intervalos contínuos estreitos podem exigir o ponto médio fora da malha. Dados observados diferem legitimamente porque a exposição escolhida altera a chance de aquisição. A autorização de reentrada simulada é **um requisito adicional autoimposto pela regra KAFKA candidata**, não uma proibição geral que todos os outros planejadores devem cumprir; as restrições externas regulares de exposição e revisão são compartilhadas.',
 '',
 'Quando os limites são incompatíveis, nenhuma ação regular é declarada admissível. Um protocolo de **contingência puramente sintético** escolhe `e=.10`, cobra revisão uma vez e impede aquisição de evidência durante esse ato (`q_true=0`); a liberação exige dados de limites viáveis e assinatura exógena. A ação de contingência não constitui autorização médica ou regulatória.',
 '',
 '## 3. Métodos comparados',
 '',
 '- **`kafka_gate`:** regra candidata simplificada com sondas programadas, limiar de crença `.80`, idade da coorte ≤2 períodos e permissão de reentrada exógena. **Não** é a implementação integral do KAFKA III.',
 '- **`nominal_bayes`:** programação dinâmica Bayes exatamente ótima **dentro do modelo estático assumido**, com a mesma grade de ações e orçamento.',
 '- **`robust_bayes_mix`:** programação dinâmica de uma mistura Bayes pré-definida de precisões `.55` e `.85`; não é um ótimo minimax geral.',
 '- **`minimax_one_step`:** regra de proteção de pior risco **de um período** com envelope de prior ±.35; não é um POMDP robusto ótimo.',
 '- **`greedy`:** otimização míope de perda imediata; **`safe_static_proxy`:** ação estática conservadora sem exposição; **`historical_on`:** exposição histórica fixa; **`sentinel` e `fixed_probe`:** sondagens fixas em calendários distintos.',
 '',
 'O código do safe policy learning histórico (v1.8A) não foi reconstruído neste ensaio. Portanto, a equivalência de `safe_static_proxy` com o método histórico exigida pelo protocolo candidato **não foi demonstrada**.',
 '',
 '## 4. Desenho experimental e reprodutibilidade',
 '',
 '- **18 famílias de geradores:** nominal; benefício, dano, nulo; três reversões; estratos; sinal invertido/fraco; prior deslocado; censura informativa; atraso; baixa positividade; congestão de cluster como proxy; conflito; lacuna de grade; precisão variável.',
 '- **9 políticas × 800 trajetórias/família × 18 famílias = 129.600 trajetórias** de seis decisões sintéticas cada.',
 '- Sementes inteiras por família: `20261111+1009*i`, `i=0,…,17`. Fluxos de uniformes exógenos compartilhados entre políticas por trajetória; **não** sementes finais retidas por avaliador externo.',
 '- Todos os parâmetros, cenários e funções constam em `experiment_v1_9e.py` e `metadata.json`.',
 '- Contrastes pareados e intervalos normais 95% Monte Carlo **descritivos, não ajustados para multiplicidade**. Não existem intervalos de confiança causais ou sequências de confiança do efeito de tratamento.',
 '',
 '## 5. Resultados completos — perda acumulada média',
 '',
 'Quanto menor o valor, menor a perda **do gerador sintético**; valores não são benefícios clínicos calibrados.',
 '',
 '| Família | KAFKA | Bayes nominal | Bayes mistura | Estática segura (proxy) |',
 '|---|---:|---:|---:|---:|',
]
for f in order:
    lines.append('| '+label[f]+' | '+ ' | '.join(format_n(n(f,p)) for p in ('kafka_gate','nominal_bayes','robust_bayes_mix','safe_static_proxy'))+' |')
lines += [
 '',
 'Tabela de todas as nove políticas, componentes de perda, métricas operacionais e respectivos erros-padrão: `results_policy_metrics.csv`. Todas as diferenças pareadas disponíveis em `results_paired_differences.csv`.',
 '',
 '### 5.1 Contrastes centrais (diferença pareada = perda do comparador − perda KAFKA)',
 '',
 'Sinal negativo significa que **KAFKA teve maior perda**. Os intervalos são apenas de variação Monte Carlo e não controlam seleção ou multiplicidade.',
 '',
 '| Família | Comparador | Diferença comparador − KAFKA | IC Monte Carlo 95% |',
 '|---|---|---:|---|',
]
for f,p in [('nominal_static','nominal_bayes'),('nominal_static','safe_static_proxy'),
            ('always_benefit','nominal_bayes'),('always_harm','safe_static_proxy'),
            ('null_effect','safe_static_proxy'),('inverted_signal','safe_static_proxy'),
            ('reverse_after_reentry_window','safe_static_proxy'),
            ('delayed_outcomes','nominal_bayes'),('weak_positivity','safe_static_proxy'),
            ('benefit_to_harm','nominal_bayes')]:
    lines.append(f'| {label[f]} | `{p}` | {format_n(gain(f,p))} | {dci(f,p)} |')
lines += [
 '',
 '### 5.2 Falhas que devem permanecer no manuscrito',
 '',
 f'- **Dano persistente:** perda KAFKA `{format_n(n("always_harm","kafka_gate"))}` contra `{format_n(n("always_harm","safe_static_proxy"))}` do baseline estático. A aquisição e decisões erradas podem criar dano desnecessário.',
 f'- **Sinal invertido:** perda KAFKA `{format_n(n("inverted_signal","kafka_gate"))}` contra `{format_n(n("inverted_signal","safe_static_proxy"))}` estático. Evidência enganosa pode reforçar autoridade sem justificação.',
 f'- **Reversões sucessivas:** perda KAFKA `{format_n(n("reverse_after_reentry_window","kafka_gate"))}` contra `{format_n(n("reverse_after_reentry_window","safe_static_proxy"))}` estático. A melhor decisão histórica não transporta automaticamente seu efeito para o futuro.',
 f'- **Modelo nominal:** perda KAFKA `{format_n(n("nominal_static","kafka_gate"))}` contra `{format_n(n("nominal_static","nominal_bayes"))}` do planejador Bayes. Não há vantagem incremental sobre o benchmark Bayes corretamente especificado.',
 '- **Atraso:** a idade de uma evidência é medida desde a coorte de origem; um sinal entregue tarde não pode artificialmente renovar seu prazo de validade.',
 '- **Baixa positividade/sinal fraco:** diferenças modestas podem cruzar zero nos intervalos Monte Carlo; não são demonstrações de superioridade nem equivalência.',
 '- **Efeito nulo:** sondagens com custo podem tornar política dinâmica pior que abstenção sem acrescentar benefício biológico.',
 '',
 f'Das 18 famílias, KAFKA apresentou maior média de perda que `safe_static_proxy` em **{len(fail_static)}** e que `nominal_bayes` em **{len(fail_nom)}**. Essa contagem é descritiva e depende de seleção de famílias/modelos; **não** é uma probabilidade de falha em ambientes reais.',
 '',
 '### 5.3 Métricas de decisão e auditoria',
 '',
 f'- Dano persistente: exposição alta em estado prejudicial, média **{format_n(float(mi[("always_harm","kafka_gate")]["mean_false_reentries"]))} períodos/episódio**; sinal invertido: **{format_n(float(mi[("inverted_signal","kafka_gate")]["mean_false_reentries"]))} períodos/episódio**. Métrica calculada somente pelo avaliador, não observável diretamente pela política.',
 f'- Baixa positividade: média **{format_n(float(mi[("weak_positivity","kafka_gate")]["mean_received"]))} sinais efetivamente recebidos** em seis decisões e **{format_n(float(mi[("weak_positivity","kafka_gate")]["mean_inconclusive"]))} períodos inconclusivos** por trajetória KAFKA.',
 '- Conflito de governança: **três períodos de contingência**, uma revisão por episódio e custo de revisão `0.02` em todas as trajetórias daquela família; o estado permanece não resolvido até atualização externa assinada. O sinal não é criado pelo mecanismo de revisão.',
 '- Lacuna da malha: o intervalo contínuo `[.37,.43]` é admissível, mas não contém ponto na malha; a ação regular `.40` pode ser usada quando resta orçamento. `NO_GRID_ACTION` não é confundido com `NO_REGULAR_ACTION`.',
 '- Nenhuma trajetória final excedeu duas sondagens **regulares**, e a auditoria da regra KAFKA não identificou reentrada acima do limiar sem credencial simulada e evidência recente. Isso garante apenas consistência do código nas hipóteses testadas, não segurança clínica.',
 '- `false_suspends`, `false_reentries`, decisões inconclusivas, evidências tardias, custo de aquisição, custos de revisão e contingência estão disponíveis por política e família no CSV. As contagens de exposição alta sob dano não pressupõem que tenha existido uma reentrada após uma suspensão formal.',
 '',
 '## 6. Proposição analítica de limite informacional (clássica)',
 '',
 '**Proposição condicional.** Suponha um período futuro com efeito de magnitude `d>0`, sem observação capaz de distinguir dois mundos igualmente compatíveis com o mesmo histórico: no mundo A, expor beneficia; no mundo B, expor prejudica. A perda de uma ação aleatória/contínua com exposição média `e∈[0,1]` é `d(1-e)` no primeiro mundo e `de` no segundo. Logo `max{d(1-e), de}≥d/2`, com mínimo em `e=1/2`. Restringir ações não pode melhorar essa cota.',
 '',
 '**Interpretação:** na ausência de qualquer hipótese de transporte temporal ou dado prospectivo antes da decisão, nenhum controlador pode garantir perda menor que `d/2` em ambos os mundos nesse problema simples. Isso é um argumento minimax elementar, **não** um teorema novo KAFKA ou prova geral de impossibilidade clínica. Revisões administrativas sem novos dados não eliminam indistinguibilidade estatística.',
 '',
 '## 7. Gates metodológicos — decisão',
 '',
 '| Gate | Estado | Razão |',
 '|---|---|---|',
 '| Fidelidade de ações/custos/informação do toy | Parcial | Mesmo mecanismo de observação e orçamento; dados diferem por exposição, mas equivalência ao safe learning histórico não demonstrada |',
 '| Segurança de execução do toy | Aprovado nos testes internos | Nenhuma ação regular é forçada em conjunto vazio; contingência separada; sem dados gratuitos na contingência; revisão não concede sinal |',
 '| Robustez | **Não aprovado** | Dano, inversão de sinal e reversões mantêm resultados adversos à regra candidata |',
 '| Cobertura estatística | Não avaliado | Nenhum intervalo frequentista ou controle simultâneo de múltiplas consultas foi construído |',
 '| Cluster/interferência | Não avaliado de forma identificada | κ de congestão é proxy sem desenho hospitalar aleatorizado |',
 '| Originalidade incremental | **Não demonstrada** | Mecanismo KAFKA simplificado não melhora uniformemente Bayes e baseline estático |',
 '| Confirmação clínica | **Bloqueado** | Sem custos legitimados, registro público, avaliador externo, estimando causal ou consentimento |',
 '',
 '## 8. Testes, trilha e reconstrução',
 '',
 '- `test_v1_9e.py` contém **18 testes unitários** independentes da rotina principal, cobrindo recursão de Bellman, normalização Bayes, fronteiras de positividade, sem vazamento de verdade, idade da coorte, veto de assinatura, orçamento, contingência, estados de revisão, identidade de custos, matrizes e preservação de resultados negativos.',
 '- `check_reproducibility.py` reexecuta todas as 129.600 trajetórias e verifica a igualdade **byte a byte** de cinco arquivos principais. Ver `reproducibility_log.txt`.',
 '- `audit_example_paths.csv` possui trajetórias exemplares com crença antes da decisão, estado, sinal, exposição, timestamp de coorte e condição de assinatura. A coluna `theta_evaluator_only` pertence exclusivamente à auditoria, nunca ao planejador.',
 '- `metadata.json`, `run_log.json`, `tests_log.txt`, `manifest_sha256.txt` e `CHANGELOG_AND_LIMITATIONS.md` documentam ambiente, cenários, parâmetros, testes e correções.',
 '',
 'Executar na pasta do pacote, sem internet nem dependências externas:',
 '',
 '```bash',
 'python experiment_v1_9e.py > run_log.json',
 'python test_v1_9e.py > tests_log.txt 2>&1',
 'python check_reproducibility.py > reproducibility_log.txt',
 'python generate_report.py',
 '```',
 '',
 '## 9. Implicações editoriais e candidata v1.9F',
 '',
 'A v1.9E fortalece a parte negativa da tese (limites de autoridade, observabilidade e transporte temporal), mas **não** demonstra superioridade incremental da arquitetura KAFKA. Não existe base para artigo de eficácia, implantação ou teste com pacientes.',
 '',
 'A v1.9F, **somente após revisão externa**, deveria: (i) recuperar e demonstrar equivalência exata ao safe policy learning histórico; (ii) separar ação regular, contingência e credenciais universalmente exigidas para todos os métodos; (iii) contratar avaliador cego com sementes finais e margens clínicas pré-especificadas; (iv) usar geradores com atraso, drift, MNAR e desenlaces com identificação adequada; (v) modelar hospitais por randomização e desfechos sob interferência; (vi) construir inferência com cobertura simultânea auditada; (vii) comparar planejador Bayes/POMDP robusto e minimax multietapas genuínos; e (viii) publicar falhas e análises de sensibilidade integralmente.',
 '',
 '**Decisão final v1.9E:** pacote de falsificação exploratória concluído; **gate confirmatório não aprovado**.',
 '',
]
(ROOT/'RELATORIO_KAFKA_III_V1_9E.md').write_text('\n'.join(lines)+'\n',encoding='utf8')
print('report generated:',len(lines),'lines')
